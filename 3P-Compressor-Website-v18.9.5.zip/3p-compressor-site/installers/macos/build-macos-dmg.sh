#!/usr/bin/env bash
# ==============================================================================
# 3P Compressor v18.9-Hardened — macOS Universal Native Cocoa GUI (.dmg) Builder
# Compiles desktop-source/gui_macos.mm + p3cli.cpp for Apple Silicon & Intel
# Run on macOS (Xcode Command Line Tools required):
#   chmod +x build-macos-dmg.sh && ./build-macos-dmg.sh
# Output: ../../downloads/3P-Compressor-macOS.dmg
# ==============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SITE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
DS_DIR="$SITE_ROOT/desktop-source"
STAGE="$SCRIPT_DIR/stage_dmg"
APP="$STAGE/3P Compressor.app"
OUT_DMG="$SITE_ROOT/downloads/3P-Compressor-macOS.dmg"

mkdir -p "$SITE_ROOT/downloads"
rm -rf "$STAGE" "$OUT_DMG"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

echo "[1/5] Compiling Universal macOS Cocoa GUI (arm64 + x86_64)..."
clang++ -std=c++17 -O3 -DNDEBUG -fobjc-arc -ObjC++ -pthread -arch arm64  -framework Cocoa "$DS_DIR/gui_macos.mm" -I"$DS_DIR" -o "$STAGE/gui_arm64"
clang++ -std=c++17 -O3 -DNDEBUG -fobjc-arc -ObjC++ -pthread -arch x86_64 -framework Cocoa "$DS_DIR/gui_macos.mm" -I"$DS_DIR" -o "$STAGE/gui_x86_64"
lipo -create "$STAGE/gui_arm64" "$STAGE/gui_x86_64" -output "$APP/Contents/MacOS/3P-Compressor"
rm -f "$STAGE/gui_arm64" "$STAGE/gui_x86_64"
chmod 755 "$APP/Contents/MacOS/3P-Compressor"

echo "[2/5] Compiling Universal macOS CLI (p3cli)..."
clang++ -std=c++17 -O3 -DNDEBUG -pthread -arch arm64  "$DS_DIR/p3cli.cpp" -I"$DS_DIR" -o "$STAGE/p3cli_arm64"
clang++ -std=c++17 -O3 -DNDEBUG -pthread -arch x86_64 "$DS_DIR/p3cli.cpp" -I"$DS_DIR" -o "$STAGE/p3cli_x86_64"
lipo -create "$STAGE/p3cli_arm64" "$STAGE/p3cli_x86_64" -output "$APP/Contents/MacOS/p3cli"
rm -f "$STAGE/p3cli_arm64" "$STAGE/p3cli_x86_64"
chmod 755 "$APP/Contents/MacOS/p3cli"

echo "[3/5] Generating native macOS AppIcon.icns..."
ICON_SRC=""
if [ -f "$DS_DIR/app.ico" ]; then ICON_SRC="$DS_DIR/app.ico"; fi
if [ -n "$ICON_SRC" ] && command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
  ICONSET="$STAGE/AppIcon.iconset"
  mkdir -p "$ICONSET"
  sips -s format png "$ICON_SRC" --out "$STAGE/base_icon.png" >/dev/null 2>&1 || true
  if [ -f "$STAGE/base_icon.png" ]; then
    for sz in 16 32 128 256 512; do
      sips -z "$sz" "$sz" "$STAGE/base_icon.png" --out "$ICONSET/icon_${sz}x${sz}.png" >/dev/null 2>&1 || true
      sz2=$((sz * 2))
      sips -z "$sz2" "$sz2" "$STAGE/base_icon.png" --out "$ICONSET/icon_${sz}x${sz}@2x.png" >/dev/null 2>&1 || true
    done
    iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns" 2>/dev/null || true
    rm -rf "$ICONSET" "$STAGE/base_icon.png"
  fi
fi

echo "[4/5] Writing Info.plist with .3p file association..."
cat > "$APP/Contents/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>3P Compressor</string>
  <key>CFBundleDisplayName</key><string>3P Compressor</string>
  <key>CFBundleIdentifier</key><string>com.3pcompressor.app</string>
  <key>CFBundleVersion</key><string>18.9</string>
  <key>CFBundleShortVersionString</key><string>18.9</string>
  <key>CFBundleExecutable</key><string>3P-Compressor</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>CFBundleDocumentTypes</key>
  <array>
    <dict>
      <key>CFBundleTypeName</key><string>3P Compressed Archive</string>
      <key>CFBundleTypeExtensions</key><array><string>3p</string></array>
      <key>CFBundleTypeRole</key><string>Viewer</string>
      <key>LSHandlerRank</key><string>Owner</string>
    </dict>
  </array>
</dict>
</plist>
EOF

echo "[5/5] Creating Applications symlink and packaging $OUT_DMG..."
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "3P Compressor v18.9" -srcfolder "$STAGE" -ov -format UDZO "$OUT_DMG"
rm -rf "$STAGE"
echo "SUCCESS: Created $OUT_DMG"
