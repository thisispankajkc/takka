#!/usr/bin/env bash
# ==============================================================================
# 3P Compressor v18.9-Hardened — Linux (.deb) Setup Builder
# Output: ../../downloads/3P-Compressor-18.9-linux-amd64.deb
# ==============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SITE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
STAGE="$SCRIPT_DIR/stage_deb"
OUT_DEB="$SITE_ROOT/downloads/3P-Compressor-18.9-linux-amd64.deb"

rm -rf "$STAGE"
mkdir -p "$STAGE/DEBIAN" "$STAGE/usr/local/bin" "$STAGE/usr/share/doc/3p-compressor"

g++ -std=c++17 -O3 -DNDEBUG -pthread "$SITE_ROOT/p3cli.cpp" -I"$SITE_ROOT" -o "$STAGE/usr/local/bin/p3cli"
chmod 755 "$STAGE/usr/local/bin/p3cli"
ln -sf p3cli "$STAGE/usr/local/bin/3p-compressor"
cp "$SITE_ROOT/desktop-source/README.txt" "$STAGE/usr/share/doc/3p-compressor/README.txt"

cat > "$STAGE/DEBIAN/control" <<'EOF'
Package: 3p-compressor
Version: 18.9-1
Section: utils
Priority: optional
Architecture: amd64
Maintainer: 3P Compressor <projectloweber@gmail.com>
Description: 3P Compressor v18.9-Hardened — Scalable, Fast, Universal Lossless Compressor
 High-speed multi-threaded C++17 lossless compressor featuring Global
 Deduplication, Auto Byte-Plane Shuffle + Delta, Fast LZ77+rANS (-f),
 Max PAQ context mixing (-m), and Zero-Bloat Passthrough.
EOF

dpkg-deb --build --root-owner-group "$STAGE" "$OUT_DEB"
rm -rf "$STAGE"
echo "SUCCESS: Created $OUT_DEB"
