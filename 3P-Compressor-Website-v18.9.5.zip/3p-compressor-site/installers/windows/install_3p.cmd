@echo off
setlocal
set "APPDIR=%LOCALAPPDATA%\3P Compressor"
if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /Y "3P-Compressor.exe" "%APPDIR%\3P-Compressor.exe" >nul
copy /Y "p3cli.exe" "%APPDIR%\p3cli.exe" >nul
copy /Y "README.txt" "%APPDIR%\README.txt" >nul
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\3P Compressor.lnk'); $s.TargetPath='%APPDIR%\3P-Compressor.exe'; $s.WorkingDirectory='%APPDIR%'; $s.Save()" >nul 2>&1
reg add "HKCU\Software\Classes\.3p" /ve /d "ThreePArchive" /f >nul 2>&1
reg add "HKCU\Software\Classes\ThreePArchive\DefaultIcon" /ve /d "%APPDIR%\3P-Compressor.exe,0" /f >nul 2>&1
reg add "HKCU\Software\Classes\ThreePArchive\shell\open\command" /ve /d "\"%APPDIR%\3P-Compressor.exe\" \"%%1\"" /f >nul 2>&1
start "" "%APPDIR%\3P-Compressor.exe"
exit /b 0
