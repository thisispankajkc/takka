@echo off
rem ============================================================================
rem  3P Compressor v18.9-Hardened — Build Windows Binaries + Setup.exe Installer
rem  Requires: MinGW-w64 (g++ & windres in PATH)
rem  Uses Inno Setup 6 if installed, or Windows built-in IExpress automatically!
rem  Output:   downloads\3P-Compressor-Setup.exe  +  p3cli.exe (website root)
rem ============================================================================
setlocal
set "SCRIPT_DIR=%~dp0"
set "SITE_ROOT=%SCRIPT_DIR%..\.."
set "DS_DIR=%SITE_ROOT%\desktop-source"
set "DL_DIR=%SITE_ROOT%\downloads"
if not exist "%DL_DIR%" mkdir "%DL_DIR%"

where g++ >nul 2>&1
if errorlevel 1 (
  echo [ERROR] g++ was not found in PATH.
  echo Install MSYS2 UCRT64 or WinLibs MinGW-w64 and add its bin folder to PATH.
  pause
  exit /b 1
)

cd /d "%DS_DIR%"
echo [1/4] Compiling Windows GUI and CLI (v18.9-Hardened)...
windres app.rc -O coff -o app.res
if errorlevel 1 goto :fail
g++ -std=c++17 -O3 -mavx2 -flto=auto -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -DUNICODE -D_UNICODE -mwindows -municode -static -static-libgcc -static-libstdc++ -o 3P-Compressor.exe gui_win32.cpp app.res -lgdiplus -lcomdlg32 -lshell32 -lole32 -luuid -lgdi32 -luser32 -ladvapi32
if errorlevel 1 goto :fail
g++ -std=c++17 -O3 -mavx2 -flto=auto -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -static -static-libgcc -static-libstdc++ -o p3cli.exe p3cli.cpp
if errorlevel 1 goto :fail

echo [2/4] Copying p3cli.exe to website backend root...
copy /Y "p3cli.exe" "%SITE_ROOT%\p3cli.exe" >nul

echo [3/4] Checking for Inno Setup 6 (optional)...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if "%ISCC%"=="" (
  where iscc.exe >nul 2>&1 && set "ISCC=iscc.exe"
)

cd /d "%SCRIPT_DIR%"
if not "%ISCC%"=="" (
  echo [4/4] Building downloads\3P-Compressor-Setup.exe with Inno Setup 6...
  "%ISCC%" "3P-Compressor-Setup.iss"
  if errorlevel 1 goto :fail
  goto :done
)

echo [4/4] Inno Setup 6 not found — building downloads\3P-Compressor-Setup.exe via built-in Windows IExpress...
set "STAGE=%SCRIPT_DIR%stage_iex"
if exist "%STAGE%" rmdir /s /q "%STAGE%"
mkdir "%STAGE%"
copy /Y "%DS_DIR%\3P-Compressor.exe" "%STAGE%\" >nul
copy /Y "%DS_DIR%\p3cli.exe" "%STAGE%\" >nul
copy /Y "%DS_DIR%\README.txt" "%STAGE%\" >nul
copy /Y "%SCRIPT_DIR%install_3p.cmd" "%STAGE%\" >nul

for %%I in ("%DL_DIR%\3P-Compressor-Setup.exe") do set "OUT_EXE=%%~fI"
for %%I in ("%STAGE%") do set "STAGE_ABS=%%~fI"
set "SED=%STAGE_ABS%\setup.sed"

(
echo [Version]
echo Class=IEXPRESS
echo SEDVersion=3
echo [Options]
echo PackagePurpose=InstallApp
echo ShowInstallProgramWindow=0
echo HideExtractAnimation=0
echo UseLongFileName=1
echo InsideCompressed=0
echo CAB_FixedSize=0
echo CAB_ResvCodeSigning=0
echo RebootMode=N
echo InstallPrompt=Install 3P Compressor v18.9-Hardened?
echo DisplayLicense=
echo FinishMessage=3P Compressor v18.9-Hardened has been installed.
echo TargetName=%OUT_EXE%
echo FriendlyName=3P Compressor v18.9 Setup
echo AppLaunched=cmd.exe /c install_3p.cmd
echo PostInstallCmd=^<None^>
echo AdminQuietInstCmd=
echo UserQuietInstCmd=
echo SourceFiles=SourceFiles
echo [Strings]
echo FILE0="3P-Compressor.exe"
echo FILE1="p3cli.exe"
echo FILE2="README.txt"
echo FILE3="install_3p.cmd"
echo [SourceFiles]
echo SourceFiles0=%STAGE_ABS%\
echo [SourceFiles0]
echo %%FILE0%%=
echo %%FILE1%%=
echo %%FILE2%%=
echo %%FILE3%%=
) > "%SED%"

iexpress.exe /N /Q "%SED%"
if errorlevel 1 goto :fail
rmdir /s /q "%STAGE%"

:done
echo.
echo SUCCESS: Created %DL_DIR%\3P-Compressor-Setup.exe
echo Refresh the website — the Windows download button is now live!
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Check errors above.
pause
exit /b 1
