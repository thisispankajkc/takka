; 3P Compressor v18.9-Hardened — Windows Setup Installer Script (Inno Setup 6)
; Produces: downloads\3P-Compressor-Setup.exe
#define MyAppName "3P Compressor"
#define MyAppVersion "18.9"
#define MyAppPublisher "3P Compressor"
#define MyAppURL "mailto:projectloweber@gmail.com"
#define MyAppExeName "3P-Compressor.exe"

[Setup]
AppId={{7B4E3P18-9001-4C5A-8B2E-3PCOMPRESSOR189}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
ChangesAssociations=yes
OutputDir=..\..\downloads
OutputBaseFilename=3P-Compressor-Setup
SetupIconFile=..\..\desktop-source\app.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequiredOverridesAllowed=dialog

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "assoc3p"; Description: "Associate .3p archives with 3P Compressor"; GroupDescription: "File Integration:"

[Files]
Source: "..\..\desktop-source\3P-Compressor.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\desktop-source\p3cli.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\desktop-source\README.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Registry]
Root: HKA; Subkey: "Software\Classes\.3p"; ValueType: string; ValueName: ""; ValueData: "ThreePArchive"; Flags: uninsdeletevalue; Tasks: assoc3p
Root: HKA; Subkey: "Software\Classes\ThreePArchive"; ValueType: string; ValueName: ""; ValueData: "3P Compressed Archive"; Flags: uninsdeletekey; Tasks: assoc3p
Root: HKA; Subkey: "Software\Classes\ThreePArchive\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0"; Tasks: assoc3p
Root: HKA; Subkey: "Software\Classes\ThreePArchive\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExeName}"" ""%1"""; Tasks: assoc3p

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
