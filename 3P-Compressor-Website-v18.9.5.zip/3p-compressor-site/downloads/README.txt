3P Compressor v18.9-Hardened — Release Installers
==================================================
Linux (Ready to Install — Prebuilt in this package):
  - Debian / Ubuntu (.deb):  3P-Compressor-18.9-linux-amd64.deb
      Install: sudo dpkg -i 3P-Compressor-18.9-linux-amd64.deb
  - Universal Linux (.sh):   3P-Compressor-18.9-linux-setup.sh
      Install: chmod +x 3P-Compressor-18.9-linux-setup.sh && ./3P-Compressor-18.9-linux-setup.sh

Windows (Build locally on Windows 10/11):
  - Expected filename:       3P-Compressor-Setup.exe
  - One-click builder:       installers\windows\build-windows-setup.bat
    (Compiles 3P-Compressor.exe + p3cli.exe and packages via Inno Setup 6)

macOS (Build locally on macOS 12+):
  - Expected filename:       3P-Compressor-macOS.dmg
  - One-click builder:       installers/macos/build-macos-dmg.sh
    (Compiles Universal arm64+x86_64 p3cli, creates 3P Compressor.app + .dmg)

Contact: projectloweber@gmail.com | +977 9800761880
