// 3P Compressor - native macOS Cocoa + CoreGraphics front-end for the 3P engine (v18.9-Hardened).
// Matches gui_win32.cpp 1:1: Browse -> Compress (any file) / Extract (.3p file) -> Cancel while running.
// Build (Universal arm64 + x86_64):
//   clang++ -std=c++17 -O3 -DNDEBUG -fobjc-arc -ObjC++ -pthread -framework Cocoa gui_macos.mm -o 3P-Compressor

#import <Cocoa/Cocoa.h>
#include <sys/sysctl.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <string>
#include <thread>
#include "engine3p.hpp"

namespace {

constexpr CGFloat kLogicalW = 640.0;
constexpr CGFloat kLogicalH = 400.0;

using u64 = unsigned long long;
namespace fs = std::filesystem;

enum Mode { kHome, kReady, kBusy };

struct AppState {
    Mode mode = kHome;
    bool extract = false;
    fs::path file;
    std::string shownName;            // UTF-8 original filename (for .3p: read from header metadata)
    u64 before = 0, after = 0;
    std::atomic<u64> progressPpm{0};  // 0..1,000,000
    std::atomic<u64> outBytes{0};
    std::atomic<bool> cancel{false};
    double progress = 0.0;
    std::string info;
    bool infoIsError = false;
    std::thread worker;
    std::chrono::steady_clock::time_point startTime;
    bool hover = false, pressed = false;
    bool fastMode = true;             // Fast (default) vs Max (PAQ)
    bool hoverFast = false, hoverMax = false;
    NSRect buttonRect = NSZeroRect;
    NSRect toggleFastRect = NSZeroRect;
    NSRect toggleMaxRect = NSZeroRect;
} g;

// ------------------------------------------------------------------ formatting helpers
NSString* toNS(const std::string& s) {
    NSString* ns = [NSString stringWithUTF8String:s.c_str()];
    return ns ? ns : @"";
}

std::string fmtSize(u64 bytes) {
    if (bytes == 0) return "0 GB";
    static const char* unit[] = {"B", "KB", "MB", "GB", "TB"};
    double v = (double)bytes;
    int u = 0;
    while (v >= 1024.0 && u < 4) { v /= 1024.0; u++; }
    char buf[48];
    if (u == 0) std::snprintf(buf, sizeof buf, "%llu B", bytes);
    else if (v >= 100.0) std::snprintf(buf, sizeof buf, "%.0f %s", v, unit[u]);
    else std::snprintf(buf, sizeof buf, "%.1f %s", v, unit[u]);
    return buf;
}

std::string fmtDuration(double sec) {
    char buf[48];
    if (sec < 90.0) std::snprintf(buf, sizeof buf, "%d s", (int)(sec + 0.5));
    else if (sec < 5400.0) std::snprintf(buf, sizeof buf, "%d min", (int)(sec / 60.0 + 0.5));
    else std::snprintf(buf, sizeof buf, "%d h %d min", (int)(sec / 3600.0), (int)(((long long)sec % 3600) / 60));
    return buf;
}

bool hasExt3p(const fs::path& p) {
    std::string e = p.extension().u8string();
    for (char& c : e) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return e == ".3p";
}

u64 physicalMemoryBytes() {
    uint64_t mem = 0;
    size_t len = sizeof(mem);
    if (sysctlbyname("hw.memsize", &mem, &len, nullptr, 0) == 0 && mem > 0) return (u64)mem;
    return (u64)4ULL << 30;
}

double percentSmaller() {
    if (g.mode == kHome && g.before == 0) return 0.0;
    double v = 0.0;
    if (g.extract) {
        if (g.after > 0) v = 1.0 - (double)g.before / (double)g.after;
    } else {
        double processed = (double)g.before * g.progress;
        if (processed > 0.0) v = 1.0 - (double)g.after / processed;
    }
    return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v);
}

// ------------------------------------------------------------------ CoreGraphics helpers
NSColor* rgba(int r, int grn, int b, int a = 255) {
    return [NSColor colorWithSRGBRed:r / 255.0 green:grn / 255.0 blue:b / 255.0 alpha:a / 255.0];
}

void fillPill(CGFloat x, CGFloat y, CGFloat w, CGFloat h, NSColor* color) {
    if (w <= 0.5 || h <= 0.5) return;
    CGFloat radius = std::min(w, h) * 0.5;
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:NSMakeRect(x, y, w, h) xRadius:radius yRadius:radius];
    [color setFill];
    [path fill];
}

void drawTextCentered(NSString* text, NSFont* font, NSColor* color, CGFloat x, CGFloat y, CGFloat w, CGFloat h) {
    if (!text || text.length == 0) return;
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = NSTextAlignmentCenter;
    ps.lineBreakMode = NSLineBreakByTruncatingTail;
    NSDictionary* attrs = @{
        NSFontAttributeName: font,
        NSForegroundColorAttributeName: color,
        NSParagraphStyleAttributeName: ps
    };
    NSSize sz = [text sizeWithAttributes:attrs];
    CGFloat ty = y + (h - sz.height) * 0.5;
    [text drawInRect:NSMakeRect(x, ty, w, sz.height) withAttributes:attrs];
}

} // namespace

// ------------------------------------------------------------------ Main Custom View
@interface P3CanvasView : NSView
- (void)selectFilePath:(const fs::path&)path;
- (void)browseForFile;
- (void)triggerPrimaryButton;
- (void)cancelAndWaitIfBusy;
@end

@implementation P3CanvasView {
    NSTrackingArea* _trackingArea;
}

- (instancetype)initWithFrame:(NSRect)frameRect {
    self = [super initWithFrame:frameRect];
    if (self) {
        [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_trackingArea) [self removeTrackingArea:_trackingArea];
    NSTrackingAreaOptions opts = NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect;
    _trackingArea = [[NSTrackingArea alloc] initWithRect:self.bounds options:opts owner:self userInfo:nil];
    [self addTrackingArea:_trackingArea];
}

- (void)setHomeMessage:(const std::string&)msg isError:(BOOL)isErr {
    g.mode = kHome;
    g.info = msg;
    g.infoIsError = isErr;
    [self setNeedsDisplay:YES];
}

- (void)selectFilePath:(const fs::path&)path {
    if (g.mode == kBusy) return;
    std::error_code ec;
    if (!fs::is_regular_file(path, ec)) {
        [self setHomeMessage:"That is not a file." isError:YES];
        return;
    }
    u64 size = (u64)fs::file_size(path, ec);
    if (hasExt3p(path)) {
        p3::Result r = p3::inspect_file(path);
        if (r.status != p3::Status::Ok) {
            g.file.clear(); g.shownName.clear(); g.before = g.after = 0; g.progress = 0;
            [self setHomeMessage:"This is not a valid .3p file." isError:YES];
            return;
        }
        g.extract = true;
        g.shownName = r.storedName;
        g.before = size;
        g.after = r.outSize;
    } else {
        g.extract = false;
        g.shownName = path.filename().u8string();
        g.before = size;
        g.after = 0;
    }
    g.file = path;
    g.progress = 0.0;
    g.progressPpm.store(0);
    g.outBytes.store(0);
    g.info.clear();
    g.infoIsError = false;
    g.mode = kReady;
    [self setNeedsDisplay:YES];
}

- (void)browseForFile {
    if (g.mode == kBusy) return;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Choose a file to compress or a .3p file to extract";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = NO;
    [panel beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse result) {
        if (result == NSModalResponseOK && panel.URL.isFileURL) {
            const char* fsPath = panel.URL.fileSystemRepresentation;
            if (fsPath) [self selectFilePath:fs::path(fsPath)];
        }
    }];
}

- (void)startJob {
    if (g.mode != kReady) return;
    if (g.worker.joinable()) g.worker.join();
    g.cancel.store(false);
    g.progress = 0.0;
    g.progressPpm.store(0);
    g.outBytes.store(0);
    g.info.clear();
    g.infoIsError = false;
    g.startTime = std::chrono::steady_clock::now();
    g.mode = kBusy;
    [self setNeedsDisplay:YES];

    fs::path targetFile = g.file;
    bool doExtract = g.extract;
    bool useFast = g.fastMode && (g.before >= ((u64)512 << 10));
    u64 availMem = physicalMemoryBytes();
    u64 budget = (u64)((double)availMem * 0.6);
    if (budget < ((u64)600 << 20)) budget = ((u64)600 << 20);

    __weak P3CanvasView* weakSelf = self;
    g.worker = std::thread([weakSelf, targetFile, doExtract, useFast, budget]() {
        p3::Options opt;
        opt.fast = useFast;
        opt.memoryBudget = budget;

        auto lastPost = std::chrono::steady_clock::now() - std::chrono::milliseconds(200);
        p3::ProgressFn progress = [weakSelf, &lastPost](double f, p3::u64 out) -> bool {
            g.progressPpm.store((u64)(f * 1000000.0));
            g.outBytes.store(out);
            auto now = std::chrono::steady_clock::now();
            if (f >= 1.0 || std::chrono::duration_cast<std::chrono::milliseconds>(now - lastPost).count() >= 100) {
                lastPost = now;
                dispatch_async(dispatch_get_main_queue(), ^{
                    P3CanvasView* strongSelf = weakSelf;
                    if (!strongSelf) return;
                    g.progress = (double)g.progressPpm.load() / 1000000.0;
                    [strongSelf setNeedsDisplay:YES];
                });
            }
            return !g.cancel.load();
        };

        p3::Result res = doExtract ? p3::restore_file(targetFile, opt, progress)
                                   : p3::compress_file(targetFile, opt, progress);

        dispatch_async(dispatch_get_main_queue(), ^{
            P3CanvasView* strongSelf = weakSelf;
            if (!strongSelf) return;
            [strongSelf finishJobWithResult:res];
        });
    });
}

- (void)finishJobWithResult:(const p3::Result&)r {
    if (g.worker.joinable()) g.worker.join();
    if (r.status == p3::Status::Ok) {
        g.progress = 1.0;
        g.progressPpm.store(1000000);
        if (g.extract) {
            g.before = r.inSize;
            g.after = r.outSize;
            g.info = "Restored as  " + r.outPath.filename().u8string();
        } else {
            g.before = r.inSize;
            g.after = r.outSize;
            g.outBytes.store(r.outSize);
            g.info = "Saved as  " + r.outPath.filename().u8string();
        }
        g.infoIsError = false;
        g.mode = kHome;
    } else if (r.status == p3::Status::Cancelled) {
        g.progress = 0.0;
        g.info = "Cancelled.";
        g.infoIsError = false;
        g.mode = kReady;
    } else {
        g.info = r.message;
        g.infoIsError = true;
        g.progress = 0.0;
        g.mode = kHome;
    }
    [self setNeedsDisplay:YES];
}

- (void)triggerPrimaryButton {
    if (g.mode == kBusy) {
        g.cancel.store(true);
        g.info = "Cancelling...";
        [self setNeedsDisplay:YES];
    } else if (g.mode == kReady) {
        [self startJob];
    } else {
        [self browseForFile];
    }
}

- (void)cancelAndWaitIfBusy {
    if (g.mode == kBusy) {
        g.cancel.store(true);
        if (g.worker.joinable()) g.worker.join();
        g.mode = kHome;
    } else if (g.worker.joinable()) {
        g.worker.join();
    }
}

// ------------------------------------------------------------------ Drawing
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    CGFloat W = self.bounds.size.width;
    CGFloat H = self.bounds.size.height;
    CGFloat cx = W * 0.5;

    // Background: deep slate-blue gradient matching gui_win32.cpp
    NSGradient* bg = [[NSGradient alloc] initWithStartingColor:rgba(64, 90, 118)
                                                   endingColor:rgba(40, 62, 86)];
    [bg drawInRect:self.bounds angle:90.0];

    // 18 faint translucent panels (same deterministic LCG seed=7 as Windows)
    NSColor* faint = rgba(255, 255, 255, 9);
    [faint setFill];
    unsigned seed = 7;
    for (int i = 0; i < 18; i++) {
        seed = seed * 1664525u + 1013904223u; CGFloat x = (CGFloat)((seed >> 8) & 1023) / 1023.0 * W;
        seed = seed * 1664525u + 1013904223u; CGFloat y = (CGFloat)((seed >> 8) & 1023) / 1023.0 * H;
        seed = seed * 1664525u + 1013904223u; CGFloat rw = 60.0 + (CGFloat)((seed >> 8) & 127);
        seed = seed * 1664525u + 1013904223u; CGFloat rh = 30.0 + (CGFloat)((seed >> 8) & 63);
        NSRectFillUsingOperation(NSMakeRect(x - rw * 0.5, y - rh * 0.5, rw, rh), NSCompositingOperationSourceOver);
    }

    NSColor* white = rgba(255, 255, 255);
    NSColor* soft  = rgba(205, 220, 236);

    // Title
    drawTextCentered(@"3P Compressor", [NSFont systemFontOfSize:38 weight:NSFontWeightLight], white, 0, 26, W, 58);

    // Top-right Fast | Max mode pill toggle (hidden while extracting a .3p file)
    if (!g.extract) {
        CGFloat tw = 116, th = 28, tx = W - tw - 18, ty = 16, half = tw * 0.5;
        g.toggleFastRect = NSMakeRect(tx, ty, half, th);
        g.toggleMaxRect  = NSMakeRect(tx + half, ty, half, th);
        fillPill(tx, ty, tw, th, rgba(16, 26, 38, 55));
        NSColor* actFace   = (g.mode == kBusy) ? rgba(210, 222, 236, 150) : rgba(240, 246, 252, 245);
        NSColor* actText   = rgba(38, 54, 74);
        NSColor* inactText = (g.mode == kBusy) ? rgba(200, 216, 232, 120) : rgba(210, 224, 240, 220);
        if (g.fastMode) {
            fillPill(tx + 2, ty + 2, half - 2, th - 4, actFace);
            if (g.hoverMax && g.mode != kBusy) fillPill(tx + half, ty + 2, half - 2, th - 4, rgba(255, 255, 255, 35));
        } else {
            fillPill(tx + half, ty + 2, half - 2, th - 4, actFace);
            if (g.hoverFast && g.mode != kBusy) fillPill(tx + 2, ty + 2, half - 2, th - 4, rgba(255, 255, 255, 35));
        }
        NSFont* tf = [NSFont systemFontOfSize:12.5 weight:NSFontWeightSemibold];
        drawTextCentered(@"Fast", tf, g.fastMode ? actText : inactText, tx, ty, half, th);
        drawTextCentered(@"Max",  tf, g.fastMode ? inactText : actText, tx + half, ty, half, th);
    } else {
        g.toggleFastRect = NSZeroRect;
        g.toggleMaxRect  = NSZeroRect;
    }

    // Selected file label
    if (!g.shownName.empty()) {
        drawTextCentered(@"Selected file:", [NSFont systemFontOfSize:13 weight:NSFontWeightRegular], soft, 0, 96, W, 20);
        drawTextCentered(toNS(g.shownName), [NSFont systemFontOfSize:19 weight:NSFontWeightSemibold], white, 60, 114, W - 120, 30);
    }

    // Primary pill button
    NSString* label = (g.mode == kBusy) ? @"Cancel" : ((g.mode == kReady) ? (g.extract ? @"Extract" : @"Compress") : @"Browse");
    CGFloat bw = 190, bh = 46, bx = cx - bw * 0.5, by = 158;
    g.buttonRect = NSMakeRect(bx, by, bw, bh);
    NSColor* face = g.pressed ? rgba(214, 222, 232) : (g.hover ? rgba(255, 255, 255) : rgba(240, 244, 248));
    if (g.mode == kBusy) {
        face = g.pressed ? rgba(170, 186, 204) : (g.hover ? rgba(205, 218, 232) : rgba(186, 202, 220));
    }
    fillPill(bx, by + 2, bw, bh, rgba(0, 0, 0, 40));
    fillPill(bx, by, bw, bh, face);
    drawTextCentered(label, [NSFont systemFontOfSize:18 weight:NSFontWeightRegular], rgba(44, 60, 80), bx, by, bw, bh);

    // Status / info line
    std::string line = g.info;
    if (g.mode == kBusy) {
        double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - g.startTime).count();
        std::string pct = std::to_string((int)(g.progress * 100.0)) + "%";
        line = (g.extract ? "Extracting  " : "Compressing  ") + pct;
        double processed = (double)(g.extract ? g.after : g.before) * g.progress;
        if (elapsed > 2.0 && g.progress > 0.002) {
            double rate = processed / elapsed;
            line += "   \xC2\xB7   " + fmtSize((u64)rate) + "/s   \xC2\xB7   " + fmtDuration(elapsed * (1.0 - g.progress) / g.progress) + " left";
        }
    }
    if (!line.empty()) {
        drawTextCentered(toNS(line), [NSFont systemFontOfSize:14 weight:NSFontWeightRegular],
                         g.infoIsError ? rgba(255, 178, 168) : soft, 30, 214, W - 60, 26);
    }

    // Before / After columns
    CGFloat lx = W * 0.265, rx = W * 0.735, colW = 210;
    u64 afterShown = g.extract ? g.after : (g.mode == kBusy ? g.outBytes.load() : g.after);
    NSFont* bigNum = [NSFont systemFontOfSize:32 weight:NSFontWeightSemibold];
    NSFont* subLbl = [NSFont systemFontOfSize:16 weight:NSFontWeightRegular];
    drawTextCentered(toNS(fmtSize(g.before)), bigNum, white, lx - colW * 0.5, 252, colW, 44);
    drawTextCentered(@"before", subLbl, soft, lx - colW * 0.5, 296, colW, 24);
    drawTextCentered(toNS(fmtSize(afterShown)), bigNum, white, rx - colW * 0.5, 252, colW, 44);
    drawTextCentered(@"after", subLbl, soft, rx - colW * 0.5, 296, colW, 24);

    // Progress bars
    CGFloat barW = 190, barH = 15, barY = 334;
    NSColor* track = rgba(214, 226, 240, 70);
    fillPill(lx - barW * 0.5, barY, barW, barH, track);
    fillPill(rx - barW * 0.5, barY, barW, barH, track);
    double leftFill = g.progress, rightFill = 0.0;
    if (g.extract) rightFill = g.progress;
    else if (g.before > 0) rightFill = std::min(1.0, (double)afterShown / (double)g.before);
    if (g.mode == kHome && g.before == 0) { leftFill = 0.0; rightFill = 0.0; }
    fillPill(lx - barW * 0.5, barY, barW * leftFill,  barH, rgba(238, 200, 122));
    fillPill(rx - barW * 0.5, barY, barW * rightFill, barH, rgba(128, 222, 152));

    // Centre: percentage smaller
    double pct = percentSmaller();
    NSString* pctStr = [NSString stringWithFormat:@"%d%%", (int)(pct * 100.0 + 0.5)];
    drawTextCentered(pctStr, [NSFont systemFontOfSize:28 weight:NSFontWeightSemibold], white, cx - 60, 308, 120, 36);
    drawTextCentered(@"smaller", [NSFont systemFontOfSize:15 weight:NSFontWeightRegular], soft, cx - 60, 342, 120, 22);
}

// ------------------------------------------------------------------ Mouse & Keyboard
- (void)mouseMoved:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    bool over = NSPointInRect(p, g.buttonRect);
    bool hf = (g.mode != kBusy && !g.extract && NSPointInRect(p, g.toggleFastRect));
    bool hm = (g.mode != kBusy && !g.extract && NSPointInRect(p, g.toggleMaxRect));
    if (over != g.hover || hf != g.hoverFast || hm != g.hoverMax) {
        g.hover = over; g.hoverFast = hf; g.hoverMax = hm;
        [self setNeedsDisplay:YES];
    }
    if (over || hf || hm) [[NSCursor pointingHandCursor] set];
    else [[NSCursor arrowCursor] set];
}

- (void)mouseExited:(NSEvent*)event {
    (void)event;
    g.hover = g.pressed = g.hoverFast = g.hoverMax = false;
    [[NSCursor arrowCursor] set];
    [self setNeedsDisplay:YES];
}

- (void)mouseDown:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (g.mode != kBusy && !g.extract && NSPointInRect(p, g.toggleFastRect)) {
        if (!g.fastMode) { g.fastMode = true; [self setNeedsDisplay:YES]; }
        return;
    }
    if (g.mode != kBusy && !g.extract && NSPointInRect(p, g.toggleMaxRect)) {
        if (g.fastMode) { g.fastMode = false; [self setNeedsDisplay:YES]; }
        return;
    }
    if (NSPointInRect(p, g.buttonRect)) {
        g.pressed = true;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseUp:(NSEvent*)event {
    bool was = g.pressed;
    g.pressed = false;
    [self setNeedsDisplay:YES];
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (was && NSPointInRect(p, g.buttonRect)) [self triggerPrimaryButton];
}

- (void)keyDown:(NSEvent*)event {
    unsigned short kc = event.keyCode;
    if (kc == 36 || kc == 76 || kc == 49) { [self triggerPrimaryButton]; return; } // Return / Enter / Space
    if (kc == 53 && g.mode == kBusy) { [self triggerPrimaryButton]; return; }      // Escape cancels
    [super keyDown:event];
}

// ------------------------------------------------------------------ Drag & Drop
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    if (g.mode == kBusy) return NSDragOperationNone;
    return NSDragOperationCopy;
}

- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    if (g.mode == kBusy) return NO;
    NSPasteboard* pb = [sender draggingPasteboard];
    NSArray<NSURL*>* urls = [pb readObjectsForClasses:@[[NSURL class]]
                                              options:@{NSPasteboardURLReadingFileURLsOnlyKey: @YES}];
    if (urls.count > 0 && urls.firstObject.isFileURL) {
        const char* fsPath = urls.firstObject.fileSystemRepresentation;
        if (fsPath) { [self selectFilePath:fs::path(fsPath)]; return YES; }
    }
    return NO;
}

@end

// ------------------------------------------------------------------ Application Delegate
@interface P3AppDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@property (strong) NSWindow* window;
@property (strong) P3CanvasView* canvas;
@end

@implementation P3AppDelegate {
    std::string _pendingOpenPath;
}

- (void)setupMenuBar {
    NSMenu* menubar = [[NSMenu alloc] init];
    NSMenuItem* appMenuItem = [[NSMenuItem alloc] init];
    [menubar addItem:appMenuItem];
    NSMenu* appMenu = [[NSMenu alloc] init];
    [appMenu addItemWithTitle:@"Quit 3P Compressor" action:@selector(terminate:) keyEquivalent:@"q"];
    [appMenuItem setSubmenu:appMenu];

    NSMenuItem* fileMenuItem = [[NSMenuItem alloc] init];
    [menubar addItem:fileMenuItem];
    NSMenu* fileMenu = [[NSMenu alloc] initWithTitle:@"File"];
    NSMenuItem* openItem = [[NSMenuItem alloc] initWithTitle:@"Open File…" action:@selector(openDocument:) keyEquivalent:@"o"];
    openItem.target = self;
    [fileMenu addItem:openItem];
    [fileMenuItem setSubmenu:fileMenu];

    [NSApp setMainMenu:menubar];
}

- (void)openDocument:(id)sender {
    (void)sender;
    [self.canvas browseForFile];
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    [self setupMenuBar];

    NSWindowStyleMask style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable;
    self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, kLogicalW, kLogicalH)
                                              styleMask:style
                                                backing:NSBackingStoreBuffered
                                                  defer:NO];
    self.window.title = @"3P Compressor";
    self.window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    self.window.delegate = self;
    self.canvas = [[P3CanvasView alloc] initWithFrame:NSMakeRect(0, 0, kLogicalW, kLogicalH)];
    self.window.contentView = self.canvas;
    [self.window center];
    [self.window makeKeyAndOrderFront:nil];
    [self.window makeFirstResponder:self.canvas];
    [NSApp activateIgnoringOtherApps:YES];

    if (!_pendingOpenPath.empty()) {
        [self.canvas selectFilePath:fs::path(_pendingOpenPath)];
        _pendingOpenPath.clear();
    }
}

- (void)application:(NSApplication*)application openURLs:(NSArray<NSURL*>*)urls {
    (void)application;
    if (urls.count == 0 || !urls.firstObject.isFileURL) return;
    const char* fsPath = urls.firstObject.fileSystemRepresentation;
    if (!fsPath) return;
    if (self.canvas) [self.canvas selectFilePath:fs::path(fsPath)];
    else _pendingOpenPath = fsPath;
}

- (BOOL)application:(NSApplication*)sender openFile:(NSString*)filename {
    (void)sender;
    if (!filename) return NO;
    const char* fsPath = filename.fileSystemRepresentation;
    if (!fsPath) return NO;
    if (self.canvas) [self.canvas selectFilePath:fs::path(fsPath)];
    else _pendingOpenPath = fsPath;
    return YES;
}

- (BOOL)windowShouldClose:(NSWindow*)sender {
    if (g.mode == kBusy) {
        NSAlert* alert = [[NSAlert alloc] init];
        alert.messageText = @"3P Compressor";
        alert.informativeText = @"A job is still running. Cancel it and quit?";
        [alert addButtonWithTitle:@"Cancel Job & Quit"];
        [alert addButtonWithTitle:@"Keep Running"];
        if ([alert runModal] != NSAlertFirstButtonReturn) return NO;
        [self.canvas cancelAndWaitIfBusy];
    }
    return YES;
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    (void)sender;
    return YES;
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;
    if (g.mode == kBusy) {
        NSAlert* alert = [[NSAlert alloc] init];
        alert.messageText = @"3P Compressor";
        alert.informativeText = @"A job is still running. Cancel it and quit?";
        [alert addButtonWithTitle:@"Cancel Job & Quit"];
        [alert addButtonWithTitle:@"Keep Running"];
        if ([alert runModal] != NSAlertFirstButtonReturn) return NSTerminateCancel;
        [self.canvas cancelAndWaitIfBusy];
    } else if (g.worker.joinable()) {
        g.worker.join();
    }
    return NSTerminateNow;
}

@end

int main(int argc, const char* argv[]) {
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        P3AppDelegate* delegate = [[P3AppDelegate alloc] init];
        [app setDelegate:delegate];
        if (argc > 1 && argv[1] && argv[1][0] != '-') {
            [delegate application:app openFile:[NSString stringWithUTF8String:argv[1]]];
        }
        [app run];
    }
    return 0;
}
