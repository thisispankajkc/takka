# bench_layers.ps1 - Build & measure L0 / L1 / L1+AVX2 / L1+AVX2+FastTrials (+LTO) with SHA-256 gate
# Usage: .\bench_layers.ps1 -Files file1,file2,file3,file4,file5,file6 [-Trials 3]
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Files,
    [int]$Trials = 3
)
$ErrorActionPreference = "Stop"

$builds = @(
    @{ Name = "L0_base";        Flags = "-O3 -DP3_LAYER1_PREFETCH=0 -DP3_AVX2_MIXER=0 -DP3_FAST_TRIALS=0" },
    @{ Name = "L1_prefetch";    Flags = "-O3 -DP3_LAYER1_PREFETCH=1 -DP3_AVX2_MIXER=0 -DP3_FAST_TRIALS=0" },
    @{ Name = "L1_avx2";        Flags = "-O3 -mavx2 -DP3_LAYER1_PREFETCH=1 -DP3_AVX2_MIXER=1 -DP3_FAST_TRIALS=0" },
    @{ Name = "L1_avx2_ft";     Flags = "-O3 -mavx2 -DP3_LAYER1_PREFETCH=1 -DP3_AVX2_MIXER=1 -DP3_FAST_TRIALS=1" },
    @{ Name = "L1_avx2_ft_lto"; Flags = "-O3 -mavx2 -flto=auto -DP3_LAYER1_PREFETCH=1 -DP3_AVX2_MIXER=1 -DP3_FAST_TRIALS=1" }
)

New-Item -ItemType Directory -Force -Path ".\bench_tmp" | Out-Null
foreach ($b in $builds) {
    $exe = ".\bench_tmp\p3cli_$($b.Name).exe"
    Write-Host "Compiling $($b.Name)..."
    $cmd = "g++ -std=c++17 $($b.Flags) -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -static -static-libgcc -static-libstdc++ -o `"$exe`" p3cli.cpp"
    Invoke-Expression $cmd
    if ($LASTEXITCODE -ne 0) { throw "Build failed for $($b.Name)" }
}

$baseHashes = @{}; $baseComp = @{}; $baseDec = @{}; $baseOut = @{}

foreach ($b in $builds) {
    $name = $b.Name
    $exe = ".\bench_tmp\p3cli_$name.exe"
    $outDir = ".\bench_tmp\out_$name"
    $decDir = ".\bench_tmp\dec_$name"
    Remove-Item -Recurse -Force $outDir, $decDir -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $outDir, $decDir | Out-Null

    $totC = 0.0; $totD = 0.0; $totOut = 0L; $gateAll = $true
    Write-Host "`n=== $name ==="
    foreach ($f in $Files) {
        $item = Get-Item $f
        $out3p = Join-Path $outDir ($item.BaseName + ".3p")
        $decFile = Join-Path $decDir $item.Name
        $origHash = (Get-FileHash $item.FullName -Algorithm SHA256).Hash

        $ct = @(); $dt = @()
        for ($t = 0; $t -lt $Trials; $t++) {
            Remove-Item -Force $out3p, $decFile -ErrorAction SilentlyContinue
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            & $exe c $item.FullName $outDir -t 1 -q | Out-Null
            $sw.Stop(); $ct += $sw.Elapsed.TotalSeconds

            $sw.Restart()
            & $exe x $out3p $decDir -t 1 -q | Out-Null
            $sw.Stop(); $dt += $sw.Elapsed.TotalSeconds
        }
        $cMed = ($ct | Sort-Object)[[int]($Trials / 2)]
        $dMed = ($dt | Sort-Object)[[int]($Trials / 2)]
        $outSz = (Get-Item $out3p).Length
        $totC += $cMed; $totD += $dMed; $totOut += $outSz

        $h3p = (Get-FileHash $out3p -Algorithm SHA256).Hash
        $hDec = (Get-FileHash $decFile -Algorithm SHA256).Hash
        if ($hDec -ne $origHash) { throw "ROUND-TRIP MISMATCH on $($item.Name) in $name!" }

        if ($name -eq "L0_base") {
            $baseHashes[$f] = $h3p; $baseComp[$f] = $cMed; $baseDec[$f] = $dMed; $baseOut[$f] = $outSz
            $gate = "BASE"; $dc = 0.0; $dd = 0.0; $do = 0
        } else {
            $ok = ($h3p -eq $baseHashes[$f])
            if (-not $ok) { $gateAll = $false }
            $gate = if ($ok) { "PASS" } else { "DIFF" }
            $dc = ($baseComp[$f] - $cMed) / $baseComp[$f] * 100.0
            $dd = ($baseDec[$f]  - $dMed) / $baseDec[$f]  * 100.0
            $do = $outSz - $baseOut[$f]
        }
        "{0,-24} out={1,8} ({2,+7}B)  comp={3,6:F3}s ({4,+6:F2}%)  dec={5,6:F3}s ({6,+6:F2}%)  gate={7}" -f $item.Name, $outSz, $do, $cMed, $dc, $dMed, $dd, $gate | Write-Host
    }
    if ($name -eq "L0_base") {
        $script:bTotC = $totC; $script:bTotD = $totD; $script:bTotOut = $totOut
    }
    $tdc = ($script:bTotC - $totC) / $script:bTotC * 100.0
    $tdd = ($script:bTotD - $totD) / $script:bTotD * 100.0
    $tdo = $totOut - $script:bTotOut
    "TOTAL                    out={0,8} ({1,+7}B)  comp={2,6:F3}s ({3,+6:F2}%)  dec={4,6:F3}s ({5,+6:F2}%)  gate={6}" -f $totOut, $tdo, $totC, $tdc, $totD, $tdd, $(if ($gateAll) {"ALL PASS"} else {"DIFF"}) | Write-Host
}
