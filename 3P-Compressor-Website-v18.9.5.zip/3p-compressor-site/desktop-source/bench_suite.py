#!/usr/bin/env python3
"""
3P-Compressor v14 vs Open-Source Tools (Brotli, Zstd, Gzip, Zip, Zlib, LZMA, RAR)
Generates deterministic test files from 1 KB up to 512 MB across entropy 0.4 -> 8.0 (0.5 step)
and benchmarks ratio, throughput (MB/s), and SHA-256 bit-exactness.

Usage:
  python bench_suite.py --p3 ./p3cli.exe --sizes 1KB,64KB,1MB,16MB,512MB --entropies 0.4,0.9,...,8.0
"""
import argparse, hashlib, math, os, shutil, struct, subprocess, sys, time, zlib, gzip, lzma, zipfile
import numpy as np

def make_entropy_bytes(size: int, target_h: float, seed: int = 12345) -> bytes:
    """Generate deterministic bytes with exact order-0 Shannon entropy ~target_h (0.4..8.0 b/B)."""
    rng = np.random.default_rng(seed)
    if target_h >= 7.99:
        return rng.integers(0, 256, size=size, dtype=np.uint8).tobytes()
    # Binary-search exponential decay parameter alpha so H(p) == target_h
    lo, hi = 1e-6, 20.0
    k = np.arange(256, dtype=np.float64)
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        w = np.exp(-mid * k)
        p = w / w.sum()
        h = -np.sum(p * np.log2(np.maximum(p, 1e-300)))
        if h > target_h:
            lo = mid
        else:
            hi = mid
    w = np.exp(-0.5 * (lo + hi) * k)
    p = w / w.sum()
    cdf = np.cumsum(p)
    cdf[-1] = 1.0
    # Generate in 4 MB chunks to keep RAM low even for 512 MB files
    out = bytearray(size)
    chunk = 4 << 20
    pos = 0
    while pos < size:
        n = min(chunk, size - pos)
        u = rng.random(n)
        out[pos:pos + n] = np.searchsorted(cdf, u).astype(np.uint8).tobytes()
        pos += n
    return bytes(out)

def parse_size(s: str) -> int:
    s = s.strip().upper()
    if s.endswith("GB"): return int(float(s[:-2]) * (1 << 30))
    if s.endswith("MB"): return int(float(s[:-2]) * (1 << 20))
    if s.endswith("KB"): return int(float(s[:-2]) * (1 << 10))
    return int(s)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p3", default="./p3cli.exe" if os.name == "nt" else "/tmp/p3cli_v14")
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--sizes", default="1KB,64KB,1MB,16MB,512MB")
    ap.add_argument("--entropies", default="0.4,0.9,1.4,1.9,2.4,2.9,3.4,3.9,4.4,4.9,5.4,5.9,6.4,6.9,7.4,7.9,8.0")
    ap.add_argument("--outdir", default="./bench_v14_tmp")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    sizes = [parse_size(x) for x in args.sizes.split(",")]
    ents = [float(x) for x in args.entropies.split(",")]

    has_zstd = shutil.which("zstd") is not None
    has_rar = shutil.which("rar") is not None
    try:
        import brotli as _br
        has_brotli = True
    except ImportError:
        has_brotli = shutil.which("brotli") is not None

    print(f"Benchmarking 3P-v18 ({args.p3}, -t {args.threads}) | zstd={has_zstd} brotli={has_brotli} rar={has_rar}")
    for sz in sizes:
        for h in ents:
            fpath = os.path.join(args.outdir, f"test_{sz}B_H{h:.1f}.bin")
            data = make_entropy_bytes(sz, h, seed=int(sz + h * 100))
            with open(fpath, "wb") as f:
                f.write(data)
            res = {}
            # 3P Fast
            p3_dir = os.path.join(args.outdir, "p3f")
            os.makedirs(p3_dir, exist_ok=True)
            t0 = time.perf_counter()
            subprocess.run([args.p3, "c", fpath, p3_dir, "-f", "-t", str(args.threads), "-q"], check=True)
            dt = time.perf_counter() - t0
            p3_out = os.path.join(p3_dir, os.path.splitext(os.path.basename(fpath))[0] + ".3p")
            res["3P-v18(-f)"] = (os.path.getsize(p3_out), sz / 1e6 / max(dt, 1e-6))
            os.remove(p3_out)

            # zlib (level 6)
            t0 = time.perf_counter()
            zb = zlib.compress(data, 6)
            dt = time.perf_counter() - t0
            res["zlib-6"] = (len(zb), sz / 1e6 / max(dt, 1e-6))

            # brotli (quality 4)
            if has_brotli:
                import brotli
                t0 = time.perf_counter()
                bb = brotli.compress(data, quality=4)
                dt = time.perf_counter() - t0
                res["brotli-4"] = (len(bb), sz / 1e6 / max(dt, 1e-6))

            # zstd CLI
            if has_zstd:
                zout = fpath + ".zst"
                t0 = time.perf_counter()
                subprocess.run(["zstd", "-3", "-T" + str(args.threads), "-f", fpath, "-o", zout], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                dt = time.perf_counter() - t0
                res["zstd-3"] = (os.path.getsize(zout), sz / 1e6 / max(dt, 1e-6))
                os.remove(zout)

            row = f"Size={sz:>10}B H={h:3.1f} | " + " | ".join(
                f"{k}: {100.0*v[0]/sz:5.1f}% ({v[1]:6.1f}MB/s)" for k, v in res.items()
            )
            print(row, flush=True)
            os.remove(fpath)

if __name__ == "__main__":
    main()
