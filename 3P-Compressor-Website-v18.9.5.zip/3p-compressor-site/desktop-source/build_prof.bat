@echo off
setlocal
cd /d "%~dp0"
echo Building p3prof.exe (with -O3 -mavx2 -flto=auto -DP3_PROFILE=1)...
g++ -std=c++17 -O3 -mavx2 -flto=auto -DP3_PROFILE=1 -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -static -static-libgcc -static-libstdc++ -o p3prof.exe p3prof.cpp
if errorlevel 1 (
  echo Build failed!
  pause
  exit /b 1
)
echo Done: p3prof.exe
echo Usage: p3prof.exe ^<your_file^> [-t 16] [-m or -f]
pause
