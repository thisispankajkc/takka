// =============================================================================
// p3cli.cpp - 3P Compressor v18.8-Final Command-Line Front-End
// =============================================================================
// Usage:
//   p3cli c <file> [outdir] [-t threads] [-f|-m] [-v] [-q]  Compress -> <name>.3p
//   p3cli x <file.3p> [outdir] [-t threads] [-q]            Extract  -> original name
//   p3cli i <file.3p>                                       Inspect stored metadata
// Flags:
//   -f          Fast universal mode (Dedup + Adaptive LZ77+rANS, default)
//   -m          Max-ratio mode (bit-level PAQ context-mixing engine)
//   -t <N>      Set worker thread count (default: min(hardware_threads, 16))
//   -v          Verify every compressed segment by decoding during compression
//   -q          Quiet mode (suppress live stderr progress bar)
// =============================================================================
#include "engine3p.hpp"                                                              // Include header-only 3P compression engine
#include <chrono>                                                                    // High-resolution steady_clock for wall-clock timing
#include <iostream>                                                                  // Standard C++ I/O streams
#ifndef _WIN32                                                                       // Non-Windows platforms (Linux/macOS)
#include <sys/resource.h>                                                            // getrusage() for peak resident set size (RSS) telemetry
#endif                                                                               // End non-Windows include guard
using namespace p3;                                                                  // Import public 3P engine API types and functions
int main(int argc, char** argv) {                                                    // CLI entry point
    if (argc < 3) { std::fprintf(stderr, "usage: p3cli c|x|i <file> [outdir] [-t threads] [-f|-m] [-v] [-q]\n"); return 2; } // Validate minimum arguments
    std::string mode = argv[1]; fs::path file = argv[2]; Options o; bool quiet = false; // Parse operation mode, input path, default options, quiet flag
    for (int i = 3; i < argc; i++) {                                                 // Iterate over optional CLI flags and output directory
        std::string a = argv[i];                                                     // Current command-line token
        if (a == "-t" && i + 1 < argc) o.threads = (unsigned)atoi(argv[++i]);        // Override worker thread count
        else if (a == "-v") o.verify = true;                                         // Enable in-flight segment decompression verification
        else if (a == "-f") o.fast = true;                                           // Select Fast LZ77+rANS universal mode
        else if (a == "-m") o.fast = false;                                          // Select classical bit-level PAQ max-ratio mode
        else if (a == "-q") quiet = true;                                            // Suppress interactive progress output
        else o.outDir = a;                                                           // Treat any positional argument as output directory
    }                                                                                // End argument parsing loop
    if (mode == "i") {                                                               // Metadata inspection mode (does not unpack payload)
        Result r = inspect_file(file);                                               // Read .3p header and original filename/size
        if (r.status != Status::Ok) { std::printf("error: %s\n", r.message.c_str()); return 1; } // Report header/IO error
        std::printf("name=%s original=%llu packed=%llu\n", r.storedName.c_str(), (unsigned long long)r.outSize, (unsigned long long)r.inSize); return 0; // Print metadata summary
    }                                                                                // End inspect mode
    auto t0 = std::chrono::steady_clock::now();                                      // Record wall-clock start timestamp
    ProgressFn pf = quiet ? ProgressFn() : ProgressFn([&](double f, u64 out) { std::fprintf(stderr, "\r%5.1f%%  out %llu   ", f * 100, (unsigned long long)out); return true; }); // Optional progress callback
    Result r = mode == "c" ? compress_file(file, o, pf) : restore_file(file, o, pf); // Dispatch compress or bit-exact extract
    double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(); // Compute elapsed wall time in seconds
    if (!quiet) std::fprintf(stderr, "\n");                                          // Finish progress line cleanly
    if (r.status != Status::Ok) { std::printf("error(%d): %s\n", (int)r.status, r.message.c_str()); return 1; } // Report engine failure
    long rss = 0;                                                                    // Peak memory usage in MB (Linux/POSIX)
#ifndef _WIN32                                                                       // Query OS resource usage on POSIX
    struct rusage ru; getrusage(RUSAGE_SELF, &ru); rss = ru.ru_maxrss / 1024;        // Convert peak RSS from KB to MB
#endif                                                                               // End POSIX RSS block
    std::printf("%s -> %s  in=%llu out=%llu  %.2fs  %.2f MB/s  peakRAM=%ldMB\n", file.string().c_str(), r.outPath.string().c_str(), // Print telemetry header
                (unsigned long long)r.inSize, (unsigned long long)r.outSize, s, (double)(mode == "c" ? r.inSize : r.outSize) / 1e6 / (s > 0 ? s : 1), rss); // Print byte counts, throughput, RAM
    return 0;                                                                        // Exit with success code
}                                                                                    // End main()
