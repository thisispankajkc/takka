// 3P Compressor - native Win32 + GDI+ front-end for the 3P engine.
// One button does everything:  Browse  ->  Compress (any file) / Extract (.3p file)  ->  Cancel while running.
#ifndef UNICODE // Guard if macro is not defined
#define UNICODE // Define preprocessor macro constant
#endif // End conditional compilation guard
#ifndef _UNICODE // Guard if macro is not defined
#define _UNICODE // Define preprocessor macro constant
#endif // End conditional compilation guard
#ifndef NOMINMAX // Guard if macro is not defined
#define NOMINMAX // Define preprocessor macro constant
#endif // End conditional compilation guard
#ifndef _WIN32_WINNT // Guard if macro is not defined
#define _WIN32_WINNT 0x0601 // Define preprocessor macro constant
#endif // End conditional compilation guard
#ifndef WINVER // Guard if macro is not defined
#define WINVER 0x0601 // Define preprocessor macro constant
#endif // End conditional compilation guard
#include <windows.h> // Include required header
#include <objidl.h> // Include required header
#include <shellapi.h> // Include required header
#include <commdlg.h> // Include required header
#include <algorithm> // Include required header
using std::min; // Type alias or namespace import
using std::max; // Type alias or namespace import
#include <gdiplus.h> // Include required header
#include <atomic> // Include required header
#include <cstdio> // Include required header
#include <string> // Include required header
#include "engine3p.hpp" // Include required header

namespace { // Open namespace scope

const UINT WM_P3_PROGRESS = WM_APP + 1; // Compute and assign value
const UINT WM_P3_DONE = WM_APP + 2; // Compute and assign value
const int kLogicalW = 640, kLogicalH = 400; // Compute and assign value

typedef unsigned long long u64; // Define type alias
namespace fs = std::filesystem; // Open namespace scope

// ------------------------------------------------------------------ application state
enum Mode { kHome, kReady, kBusy }; // Define enumeration constants

struct App { // Declare data structure / class
    HWND hwnd = nullptr; // Compute and assign value
    HINSTANCE inst = nullptr; // Compute and assign value
    ULONG_PTR gdiToken = 0; // Compute and assign value
    float scale = 1.0f; // Compute and assign value
    Mode mode = kHome; // Compute and assign value
    bool extract = false; // Compute and assign value
    fs::path file; // Execute statement
    std::wstring shownName;            // original file name (for .3p: read from the metadata)
    u64 before = 0, after = 0; // Compute and assign value
    std::atomic<u64> progressPpm{0};   // 0..1,000,000
    std::atomic<u64> outBytes{0}; // Execute statement
    std::atomic<bool> cancel{false}; // Execute statement
    double progress = 0.0; // Compute and assign value
    std::wstring info; // Execute statement
    bool infoIsError = false; // Compute and assign value
    HANDLE thread = nullptr; // Compute and assign value
    DWORD startTick = 0; // Compute and assign value
    bool hover = false, pressed = false; // Compute and assign value
    bool fastMode = true;              // Fast (default, 100+ MB/s) vs Max (classic PAQ)
    bool hoverFast = false, hoverMax = false; // Compute and assign value
    RECT button = {0, 0, 0, 0}; // Compute and assign value
    RECT toggleFast = {0, 0, 0, 0}, toggleMax = {0, 0, 0, 0}; // Compute and assign value
} g; // Execute statement

// ------------------------------------------------------------------ small helpers
std::wstring widen(const std::string& s) {                 // UTF-8 -> UTF-16
    if (s.empty()) return std::wstring(); // Conditional branch check
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0); // Compute and assign value
    std::wstring w((size_t)n, L'\0'); // Execute statement
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n); // Execute statement
    return w; // Return result to caller
} // Close scope / block
std::wstring ascii(const char* s) { std::wstring w; while (*s) w += (wchar_t)(unsigned char)*s++; return w; } // Compute and assign value

std::wstring fmtSize(u64 bytes) { // Execute statement
    if (bytes == 0) return L"0 GB"; // Conditional branch check
    static const char* unit[] = {"B", "KB", "MB", "GB", "TB"}; // Define helper function or constant
    double v = (double)bytes; int u = 0; // Compute and assign value
    while (v >= 1024.0 && u < 4) { v /= 1024.0; u++; } // Loop while condition holds
    char buf[48]; // Execute statement
    if (u == 0) std::snprintf(buf, sizeof buf, "%llu B", bytes); // Conditional branch check
    else if (v >= 100.0) std::snprintf(buf, sizeof buf, "%.0f %s", v, unit[u]); // Alternative conditional branch
    else std::snprintf(buf, sizeof buf, "%.1f %s", v, unit[u]); // Fallback branch
    return ascii(buf); // Return result to caller
} // Close scope / block
std::wstring fmtDuration(double sec) { // Execute statement
    char buf[48]; // Execute statement
    if (sec < 90) std::snprintf(buf, sizeof buf, "%d s", (int)(sec + 0.5)); // Conditional branch check
    else if (sec < 5400) std::snprintf(buf, sizeof buf, "%d min", (int)(sec / 60.0 + 0.5)); // Alternative conditional branch
    else std::snprintf(buf, sizeof buf, "%d h %d min", (int)(sec / 3600), (int)(((long long)sec % 3600) / 60)); // Fallback branch
    return ascii(buf); // Return result to caller
} // Close scope / block
bool hasExt3p(const fs::path& p) { // Execute statement
    std::wstring e = p.extension().wstring(); // Compute and assign value
    for (auto& c : e) c = (wchar_t)towlower(c); // Loop iteration
    return e == L".3p"; // Return result to caller
} // Close scope / block
int S(int v) { return (int)(v * g.scale + 0.5f); } // Execute statement
float Sf(float v) { return v * g.scale; } // Execute statement

// ------------------------------------------------------------------ drawing (GDI+)
void roundedRect(Gdiplus::GraphicsPath& path, float x, float y, float w, float h) { // Execute statement
    float r = h / 2.0f, d = r * 2.0f; // Compute and assign value
    if (w < d) { r = w / 2.0f; d = w; } // Conditional branch check
    path.AddArc(x, y, d, d, 180.0f, 90.0f); // Execute statement
    path.AddArc(x + w - d, y, d, d, 270.0f, 90.0f); // Execute statement
    path.AddArc(x + w - d, y + h - d, d, d, 0.0f, 90.0f); // Execute statement
    path.AddArc(x, y + h - d, d, d, 90.0f, 90.0f); // Execute statement
    path.CloseFigure(); // Execute statement
} // Close scope / block
void fillPill(Gdiplus::Graphics& gr, float x, float y, float w, float h, const Gdiplus::Color& c) { // Execute statement
    if (w <= 0.5f) return; // Conditional branch check
    Gdiplus::GraphicsPath path; roundedRect(path, x, y, w, h); // Execute statement
    Gdiplus::SolidBrush br(c); gr.FillPath(&br, &path); // Execute statement
} // Close scope / block
void drawText(Gdiplus::Graphics& gr, const std::wstring& text, const wchar_t* family, float px, int style, // Execute statement
              const Gdiplus::Color& color, float x, float y, float w, float h) { // Execute statement
    Gdiplus::FontFamily ff(family); // Execute statement
    const Gdiplus::FontFamily* use = &ff; // Compute and assign value
    if (ff.GetLastStatus() != Gdiplus::Ok) use = Gdiplus::FontFamily::GenericSansSerif();   // font not installed
    Gdiplus::Font font(use, px, style, Gdiplus::UnitPixel); // Execute statement
    Gdiplus::StringFormat fmt; // Execute statement
    fmt.SetAlignment(Gdiplus::StringAlignmentCenter); // Execute statement
    fmt.SetLineAlignment(Gdiplus::StringAlignmentCenter); // Execute statement
    fmt.SetTrimming(Gdiplus::StringTrimmingEllipsisCharacter); // Execute statement
    fmt.SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap); // Execute statement
    Gdiplus::SolidBrush br(color); // Execute statement
    gr.DrawString(text.c_str(), (INT)text.size(), &font, Gdiplus::RectF(x, y, w, h), &fmt, &br); // Execute statement
} // Close scope / block

double percentSmaller() { // Execute statement
    if (g.mode == kHome && g.before == 0) return 0.0; // Conditional branch check
    double v = 0.0; // Compute and assign value
    if (g.extract) { if (g.after > 0) v = 1.0 - (double)g.before / (double)g.after; } // Conditional branch check
    else { // Fallback branch
        double processed = (double)g.before * g.progress; // Compute and assign value
        if (processed > 0.0) v = 1.0 - (double)g.after / processed; // Conditional branch check
    } // Close scope / block
    return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v); // Return result to caller
} // Close scope / block

void paint(HDC hdc, int W, int H) { // Execute statement
    Gdiplus::Bitmap back(W, H, PixelFormat32bppPARGB); // Execute statement
    Gdiplus::Graphics gr(&back); // Execute statement
    gr.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias); // Execute statement
    gr.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias); // Execute statement

    // background: deep slate-blue gradient with a few faint panels (echoes the artwork in the design)
    Gdiplus::LinearGradientBrush bg(Gdiplus::Point(0, 0), Gdiplus::Point(0, H), Gdiplus::Color(255, 64, 90, 118), Gdiplus::Color(255, 40, 62, 86)); // Execute statement
    gr.FillRectangle(&bg, 0, 0, W, H); // Execute statement
    unsigned seed = 7; // Compute and assign value
    for (int i = 0; i < 18; i++) { // Loop iteration
        seed = seed * 1664525u + 1013904223u; float x = (float)(seed >> 8 & 1023) / 1023.0f * W; // Compute and assign value
        seed = seed * 1664525u + 1013904223u; float y = (float)(seed >> 8 & 1023) / 1023.0f * H; // Compute and assign value
        seed = seed * 1664525u + 1013904223u; float w = Sf(60.0f + (float)(seed >> 8 & 127)); // Compute and assign value
        seed = seed * 1664525u + 1013904223u; float h = Sf(30.0f + (float)(seed >> 8 & 63)); // Compute and assign value
        Gdiplus::SolidBrush faint(Gdiplus::Color(9, 255, 255, 255)); // Execute statement
        gr.FillRectangle(&faint, x - w / 2, y - h / 2, w, h); // Execute statement
    } // Close scope / block

    const float cx = W / 2.0f; // Compute and assign value
    const Gdiplus::Color white(255, 255, 255, 255), soft(255, 205, 220, 236); // Execute statement

    drawText(gr, L"3P Compressor", L"Segoe UI Light", Sf(40), Gdiplus::FontStyleRegular, white, 0, Sf(26), (float)W, Sf(60)); // Execute statement

    // Top-right Fast | Max mode pill toggle (hidden while extracting a .3p file)
    if (!g.extract) { // Conditional branch check
        float tw = Sf(116), th = Sf(28), tx = (float)W - tw - Sf(18), ty = Sf(16); // Compute and assign value
        float half = tw / 2.0f; // Compute and assign value
        g.toggleFast = {(LONG)tx, (LONG)ty, (LONG)(tx + half), (LONG)(ty + th)}; // Compute and assign value
        g.toggleMax  = {(LONG)(tx + half), (LONG)ty, (LONG)(tx + tw), (LONG)(ty + th)}; // Compute and assign value
        fillPill(gr, tx, ty, tw, th, Gdiplus::Color(55, 16, 26, 38)); // Execute statement
        Gdiplus::Color actFace = (g.mode == kBusy) ? Gdiplus::Color(150, 210, 222, 236) : Gdiplus::Color(245, 240, 246, 252); // Compute and assign value
        Gdiplus::Color actText(255, 38, 54, 74); // Execute statement
        Gdiplus::Color inactText = (g.mode == kBusy) ? Gdiplus::Color(120, 200, 216, 232) : Gdiplus::Color(220, 210, 224, 240); // Compute and assign value
        if (g.fastMode) { // Conditional branch check
            fillPill(gr, tx + Sf(2), ty + Sf(2), half - Sf(2), th - Sf(4), actFace); // Execute statement
            if (g.hoverMax && g.mode != kBusy) fillPill(gr, tx + half, ty + Sf(2), half - Sf(2), th - Sf(4), Gdiplus::Color(35, 255, 255, 255)); // Conditional branch check
        } else { // Execute statement
            fillPill(gr, tx + half, ty + Sf(2), half - Sf(2), th - Sf(4), actFace); // Execute statement
            if (g.hoverFast && g.mode != kBusy) fillPill(gr, tx + Sf(2), ty + Sf(2), half - Sf(2), th - Sf(4), Gdiplus::Color(35, 255, 255, 255)); // Conditional branch check
        } // Close scope / block
        drawText(gr, L"Fast", L"Segoe UI Semibold", Sf(13), Gdiplus::FontStyleRegular, g.fastMode ? actText : inactText, tx, ty, half, th); // Execute statement
        drawText(gr, L"Max",  L"Segoe UI Semibold", Sf(13), Gdiplus::FontStyleRegular, g.fastMode ? inactText : actText, tx + half, ty, half, th); // Execute statement
    } else { // Execute statement
        g.toggleFast = {0, 0, 0, 0}; g.toggleMax = {0, 0, 0, 0}; // Compute and assign value
    } // Close scope / block

    if (!g.shownName.empty()) { // Conditional branch check
        drawText(gr, L"Selected file:", L"Segoe UI", Sf(14), Gdiplus::FontStyleRegular, soft, 0, Sf(96), (float)W, Sf(20)); // Execute statement
        drawText(gr, g.shownName, L"Segoe UI Semibold", Sf(20), Gdiplus::FontStyleRegular, white, Sf(60), Sf(114), (float)W - Sf(120), Sf(30)); // Execute statement
    } // Close scope / block

    // the one button
    const wchar_t* label = g.mode == kBusy ? L"Cancel" : (g.mode == kReady ? (g.extract ? L"Extract" : L"Compress") : L"Browse"); // Compute and assign value
    float bw = Sf(190), bh = Sf(46), bx = cx - bw / 2, by = Sf(158); // Compute and assign value
    g.button.left = (LONG)bx; g.button.top = (LONG)by; g.button.right = (LONG)(bx + bw); g.button.bottom = (LONG)(by + bh); // Compute and assign value
    Gdiplus::Color face = g.pressed ? Gdiplus::Color(255, 214, 222, 232) : (g.hover ? Gdiplus::Color(255, 255, 255, 255) : Gdiplus::Color(255, 240, 244, 248)); // Compute and assign value
    if (g.mode == kBusy) face = g.pressed ? Gdiplus::Color(255, 170, 186, 204) : (g.hover ? Gdiplus::Color(255, 205, 218, 232) : Gdiplus::Color(255, 186, 202, 220)); // Conditional branch check
    fillPill(gr, bx, by + Sf(2), bw, bh, Gdiplus::Color(40, 0, 0, 0));            // soft shadow
    fillPill(gr, bx, by, bw, bh, face); // Execute statement
    drawText(gr, label, L"Segoe UI", Sf(19), Gdiplus::FontStyleRegular, Gdiplus::Color(255, 44, 60, 80), bx, by, bw, bh); // Execute statement

    // status / info line
    std::wstring line = g.info; // Compute and assign value
    if (g.mode == kBusy) { // Conditional branch check
        double elapsed = (GetTickCount() - g.startTick) / 1000.0; // Compute and assign value
        std::wstring pct = std::to_wstring((int)(g.progress * 100.0)) + L"%"; // Compute and assign value
        line = (g.extract ? L"Extracting  " : L"Compressing  ") + pct; // Compute and assign value
        double processed = (double)(g.extract ? g.after : g.before) * g.progress; // Compute and assign value
        if (elapsed > 2.0 && g.progress > 0.002) { // Conditional branch check
            double rate = processed / elapsed; // Compute and assign value
            line += L"   \u00B7   " + fmtSize((u64)rate) + L"/s   \u00B7   " + fmtDuration(elapsed * (1.0 - g.progress) / g.progress) + L" left"; // Compute and assign value
        } // Close scope / block
    } // Close scope / block
    if (!line.empty()) // Conditional branch check
        drawText(gr, line, L"Segoe UI", Sf(15), Gdiplus::FontStyleRegular, g.infoIsError ? Gdiplus::Color(255, 255, 178, 168) : soft, // Execute statement
                 Sf(30), Sf(214), (float)W - Sf(60), Sf(26)); // Execute statement

    // before / after columns
    float lx = W * 0.265f, rx = W * 0.735f, colW = Sf(210); // Compute and assign value
    u64 afterShown = g.extract ? g.after : (g.mode == kBusy ? g.outBytes.load() : g.after); // Compute and assign value
    drawText(gr, fmtSize(g.before), L"Segoe UI Semibold", Sf(34), Gdiplus::FontStyleRegular, white, lx - colW / 2, Sf(252), colW, Sf(44)); // Execute statement
    drawText(gr, L"before", L"Segoe UI", Sf(17), Gdiplus::FontStyleRegular, soft, lx - colW / 2, Sf(296), colW, Sf(24)); // Execute statement
    drawText(gr, fmtSize(afterShown), L"Segoe UI Semibold", Sf(34), Gdiplus::FontStyleRegular, white, rx - colW / 2, Sf(252), colW, Sf(44)); // Execute statement
    drawText(gr, L"after", L"Segoe UI", Sf(17), Gdiplus::FontStyleRegular, soft, rx - colW / 2, Sf(296), colW, Sf(24)); // Execute statement

    // bars: left = input processed (yellow), right = output size relative to the original (green)
    float barW = Sf(190), barH = Sf(15), barY = Sf(334); // Compute and assign value
    Gdiplus::Color track(70, 214, 226, 240); // Execute statement
    fillPill(gr, lx - barW / 2, barY, barW, barH, track); // Execute statement
    fillPill(gr, rx - barW / 2, barY, barW, barH, track); // Execute statement
    double leftFill = g.progress, rightFill = 0.0; // Compute and assign value
    if (g.extract) rightFill = g.progress; // Conditional branch check
    else if (g.before > 0) rightFill = std::min(1.0, (double)afterShown / (double)g.before); // Alternative conditional branch
    if (g.mode == kHome && g.before == 0) { leftFill = 0; rightFill = 0; } // Conditional branch check
    fillPill(gr, lx - barW / 2, barY, (float)(barW * leftFill), barH, Gdiplus::Color(255, 238, 200, 122)); // Execute statement
    fillPill(gr, rx - barW / 2, barY, (float)(barW * rightFill), barH, Gdiplus::Color(255, 128, 222, 152)); // Execute statement

    // centre: percentage smaller
    double pct = percentSmaller(); // Compute and assign value
    drawText(gr, std::to_wstring((int)(pct * 100.0 + 0.5)) + L"%", L"Segoe UI Semibold", Sf(30), Gdiplus::FontStyleRegular, white, cx - Sf(60), Sf(308), Sf(120), Sf(36)); // Execute statement
    drawText(gr, L"smaller", L"Segoe UI", Sf(16), Gdiplus::FontStyleRegular, soft, cx - Sf(60), Sf(342), Sf(120), Sf(22)); // Execute statement

    Gdiplus::Graphics screen(hdc); // Execute statement
    screen.DrawImage(&back, 0, 0); // Execute statement
} // Close scope / block

// ------------------------------------------------------------------ logic
void invalidate() { InvalidateRect(g.hwnd, nullptr, FALSE); } // Execute statement

void setHome(const std::wstring& message, bool isError) { // Execute statement
    g.mode = kHome; g.info = message; g.infoIsError = isError; invalidate(); // Compute and assign value
} // Close scope / block

void selectFile(const fs::path& path) { // Execute statement
    if (g.mode == kBusy) return; // Conditional branch check
    std::error_code ec; // Execute statement
    if (!fs::is_regular_file(path, ec)) { setHome(L"That is not a file.", true); return; } // Conditional branch check
    u64 size = (u64)fs::file_size(path, ec); // Compute and assign value
    if (hasExt3p(path)) { // Conditional branch check
        p3::Result r = p3::inspect_file(path); // Compute and assign value
        if (r.status != p3::Status::Ok) { g.file.clear(); g.shownName.clear(); g.before = g.after = 0; g.progress = 0; setHome(L"This is not a valid .3p file.", true); return; } // Conditional branch check
        g.extract = true; g.shownName = widen(r.storedName); g.before = size; g.after = r.outSize; // Compute and assign value
    } else { // Execute statement
        g.extract = false; g.shownName = path.filename().wstring(); g.before = size; g.after = 0; // Compute and assign value
    } // Close scope / block
    g.file = path; g.progress = 0.0; g.progressPpm = 0; g.outBytes = 0; g.info.clear(); g.infoIsError = false; g.mode = kReady; // Compute and assign value
    invalidate(); // Execute statement
} // Close scope / block

void browse() { // Execute statement
    wchar_t buf[32768] = {0}; // Compute and assign value
    OPENFILENAMEW ofn; ZeroMemory(&ofn, sizeof ofn); // Execute statement
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = g.hwnd; // Compute and assign value
    ofn.lpstrFilter = L"All files (*.*)\0*.*\0"; // Compute and assign value
    ofn.lpstrFile = buf; ofn.nMaxFile = 32768; // Compute and assign value
    ofn.lpstrTitle = L"Choose a file to compress or a .3p file to extract"; // Compute and assign value
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER | OFN_HIDEREADONLY; // Compute and assign value
    if (GetOpenFileNameW(&ofn)) selectFile(fs::path(std::wstring(buf))); // Conditional branch check
} // Close scope / block

DWORD WINAPI jobThread(LPVOID) { // Execute statement
    p3::Options opt; // Execute statement
    // Fast mode by default; silently auto-upgrade tiny files (< 512 KB) to PAQ for instant max ratio
    opt.fast = g.fastMode && (g.before >= ((u64)512 << 10)); // Compute and assign value
    MEMORYSTATUSEX ms; ms.dwLength = sizeof ms; // Compute and assign value
    if (GlobalMemoryStatusEx(&ms)) { // Conditional branch check
        u64 budget = (u64)(ms.ullAvailPhys * 0.6); // Compute and assign value
        opt.memoryBudget = budget < ((u64)600 << 20) ? ((u64)600 << 20) : budget; // Compute and assign value
    } // Close scope / block
    DWORD lastPost = 0; // Compute and assign value
    p3::ProgressFn progress = [&lastPost](double f, p3::u64 out) { // Compute and assign value
        g.progressPpm = (u64)(f * 1000000.0); g.outBytes = out; // Compute and assign value
        DWORD now = GetTickCount(); // Compute and assign value
        if (lastPost == 0 || (now - lastPost) >= 100 || f >= 1.0) { // Conditional branch check
            lastPost = now; // Compute and assign value
            PostMessageW(g.hwnd, WM_P3_PROGRESS, 0, 0); // Execute statement
        } // Close scope / block
        return !g.cancel.load(); // Return result to caller
    }; // Close scope / block
    p3::Result* r = new p3::Result(g.extract ? p3::restore_file(g.file, opt, progress) : p3::compress_file(g.file, opt, progress)); // Compute and assign value
    PostMessageW(g.hwnd, WM_P3_DONE, 0, (LPARAM)r); // Execute statement
    return 0; // Return result to caller
} // Close scope / block

void startJob() { // Execute statement
    if (g.mode != kReady) return; // Conditional branch check
    g.cancel = false; g.progress = 0; g.progressPpm = 0; g.outBytes = 0; g.info.clear(); g.infoIsError = false; // Compute and assign value
    g.startTick = GetTickCount(); g.mode = kBusy; // Compute and assign value
    g.thread = CreateThread(nullptr, 0, jobThread, nullptr, 0, nullptr); // Compute and assign value
    if (!g.thread) { g.mode = kReady; g.info = L"Could not start the worker thread."; g.infoIsError = true; } // Conditional branch check
    invalidate(); // Execute statement
} // Close scope / block

void onDone(p3::Result* r) { // Execute statement
    if (g.thread) { WaitForSingleObject(g.thread, INFINITE); CloseHandle(g.thread); g.thread = nullptr; } // Conditional branch check
    if (r->status == p3::Status::Ok) { // Conditional branch check
        g.progress = 1.0; g.progressPpm = 1000000; // Compute and assign value
        if (g.extract) { g.before = r->inSize; g.after = r->outSize; g.info = L"Restored as  " + r->outPath.filename().wstring(); } // Conditional branch check
        else { g.before = r->inSize; g.after = r->outSize; g.outBytes = r->outSize; g.info = L"Saved as  " + r->outPath.filename().wstring(); } // Fallback branch
        g.infoIsError = false; g.mode = kHome;                 // button becomes "Browse" again
    } else if (r->status == p3::Status::Cancelled) { // Compute and assign value
        g.progress = 0; g.info = L"Cancelled."; g.infoIsError = false; g.mode = kReady; // Compute and assign value
    } else { // Execute statement
        g.info = widen(r->message); g.infoIsError = true; g.progress = 0; g.mode = kHome; // Compute and assign value
    } // Close scope / block
    delete r; // Execute statement
    invalidate(); // Execute statement
} // Close scope / block

void onButton() { // Execute statement
    if (g.mode == kBusy) { g.cancel = true; g.info = L"Cancelling..."; invalidate(); } // Conditional branch check
    else if (g.mode == kReady) startJob(); // Alternative conditional branch
    else browse(); // Fallback branch
} // Close scope / block

bool inButton(int x, int y) { POINT p = {x, y}; return PtInRect(&g.button, p) != 0; } // Compute and assign value
bool inRect(const RECT& r, int x, int y) { POINT p = {x, y}; return PtInRect(&r, p) != 0; } // Compute and assign value

LRESULT CALLBACK wndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) { // Execute statement
    switch (msg) { // Multi-way dispatch switch
    case WM_PAINT: { // Switch branch label
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); // Compute and assign value
        RECT rc; GetClientRect(h, &rc); // Execute statement
        paint(dc, rc.right - rc.left, rc.bottom - rc.top); // Execute statement
        EndPaint(h, &ps); return 0; } // Execute statement
    case WM_ERASEBKGND: return 1; // Switch branch label
    case WM_MOUSEMOVE: { // Switch branch label
        int mx = (int)(short)LOWORD(lp), my = (int)(short)HIWORD(lp); // Compute and assign value
        bool over = inButton(mx, my); // Compute and assign value
        bool hf = (g.mode != kBusy && !g.extract && inRect(g.toggleFast, mx, my)); // Compute and assign value
        bool hm = (g.mode != kBusy && !g.extract && inRect(g.toggleMax, mx, my)); // Compute and assign value
        if (over != g.hover || hf != g.hoverFast || hm != g.hoverMax) { g.hover = over; g.hoverFast = hf; g.hoverMax = hm; invalidate(); } // Conditional branch check
        if (over || hf || hm) SetCursor(LoadCursor(nullptr, IDC_HAND)); // Conditional branch check
        TRACKMOUSEEVENT t = {sizeof t, TME_LEAVE, h, 0}; TrackMouseEvent(&t); // Compute and assign value
        return 0; } // Return result to caller
    case WM_MOUSELEAVE: g.hover = false; g.pressed = false; g.hoverFast = false; g.hoverMax = false; invalidate(); return 0; // Switch branch label
    case WM_LBUTTONDOWN: { // Switch branch label
        int mx = (int)(short)LOWORD(lp), my = (int)(short)HIWORD(lp); // Compute and assign value
        if (g.mode != kBusy && !g.extract && inRect(g.toggleFast, mx, my)) { if (!g.fastMode) { g.fastMode = true; invalidate(); } SetFocus(h); return 0; } // Conditional branch check
        if (g.mode != kBusy && !g.extract && inRect(g.toggleMax, mx, my))  { if (g.fastMode)  { g.fastMode = false; invalidate(); } SetFocus(h); return 0; } // Conditional branch check
        if (inButton(mx, my)) { g.pressed = true; SetCapture(h); invalidate(); } // Conditional branch check
        SetFocus(h); return 0; } // Execute statement
    case WM_LBUTTONUP: { // Switch branch label
        bool was = g.pressed; g.pressed = false; ReleaseCapture(); invalidate(); // Compute and assign value
        if (was && inButton((int)(short)LOWORD(lp), (int)(short)HIWORD(lp))) onButton(); // Conditional branch check
        return 0; } // Return result to caller
    case WM_KEYDOWN: // Switch branch label
        if (wp == VK_RETURN || wp == VK_SPACE) { onButton(); return 0; } // Conditional branch check
        if (wp == VK_ESCAPE && g.mode == kBusy) { onButton(); return 0; } // Conditional branch check
        break; // Exit current loop or switch
    case WM_SETCURSOR: if ((g.hover || g.hoverFast || g.hoverMax) && LOWORD(lp) == HTCLIENT) { SetCursor(LoadCursor(nullptr, IDC_HAND)); return TRUE; } break; // Switch branch label
    case WM_DROPFILES: { // Switch branch label
        HDROP drop = (HDROP)wp; wchar_t path[MAX_PATH * 4]; // Compute and assign value
        if (DragQueryFileW(drop, 0, path, MAX_PATH * 4)) selectFile(fs::path(std::wstring(path))); // Conditional branch check
        DragFinish(drop); return 0; } // Execute statement
    case WM_P3_PROGRESS: g.progress = (double)g.progressPpm.load() / 1000000.0; invalidate(); return 0; // Switch branch label
    case WM_P3_DONE: onDone((p3::Result*)lp); return 0; // Switch branch label
    case WM_CLOSE: // Switch branch label
        if (g.mode == kBusy) { // Conditional branch check
            if (MessageBoxW(h, L"A job is still running. Cancel it and quit?", L"3P Compressor", MB_YESNO | MB_ICONQUESTION) != IDYES) return 0; // Conditional branch check
            g.cancel = true; // Compute and assign value
            if (g.thread) { WaitForSingleObject(g.thread, INFINITE); CloseHandle(g.thread); g.thread = nullptr; } // Wait for worker exit
        } // Close busy check
        MSG dm; while (PeekMessageW(&dm, h, WM_P3_DONE, WM_P3_DONE, PM_REMOVE)) { delete (p3::Result*)dm.lParam; } // Drain & free any pending Result* to prevent leak on quit
        DestroyWindow(h); return 0; // Destroy window cleanly
    case WM_DESTROY: PostQuitMessage(0); return 0; // Switch branch label
    } // Close scope / block
    return DefWindowProcW(h, msg, wp, lp); // Return result to caller
} // Close scope / block

void enableDarkTitleBar(HWND h) {                           // best effort (Windows 10 2004+ / 11)
    HMODULE dwm = LoadLibraryW(L"dwmapi.dll"); // Compute and assign value
    if (!dwm) return; // Conditional branch check
    typedef HRESULT(WINAPI * SetAttr)(HWND, DWORD, LPCVOID, DWORD); // Define type alias
    SetAttr fn = (SetAttr)GetProcAddress(dwm, "DwmSetWindowAttribute"); // Compute and assign value
    BOOL on = TRUE; // Compute and assign value
    if (fn) { if (FAILED(fn(h, 20, &on, sizeof on))) fn(h, 19, &on, sizeof on); } // Conditional branch check
    FreeLibrary(dwm); // Execute statement
} // Close scope / block

}  // namespace

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR, int show) { // Execute statement
    g.inst = inst; // Compute and assign value
    Gdiplus::GdiplusStartupInput gsi; // Execute statement
    Gdiplus::GdiplusStartup(&g.gdiToken, &gsi, nullptr); // Execute statement

    HDC screen = GetDC(nullptr); // Compute and assign value
    g.scale = (float)GetDeviceCaps(screen, LOGPIXELSX) / 96.0f; // Compute and assign value
    ReleaseDC(nullptr, screen); // Execute statement

    WNDCLASSEXW wc; ZeroMemory(&wc, sizeof wc); // Execute statement
    wc.cbSize = sizeof wc; wc.lpfnWndProc = wndProc; wc.hInstance = inst; wc.lpszClassName = L"P3CompressorWindow"; // Compute and assign value
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW); // Compute and assign value
    wc.hIcon = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(1), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE | LR_SHARED); // Compute and assign value
    wc.hIconSm = wc.hIcon; // Compute and assign value
    RegisterClassExW(&wc); // Execute statement

    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX; // Compute and assign value
    RECT rc = {0, 0, S(kLogicalW), S(kLogicalH)}; // Compute and assign value
    AdjustWindowRectEx(&rc, style, FALSE, WS_EX_ACCEPTFILES); // Execute statement
    int w = rc.right - rc.left, hgt = rc.bottom - rc.top; // Compute and assign value
    int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2, y = (GetSystemMetrics(SM_CYSCREEN) - hgt) / 2; // Compute and assign value
    g.hwnd = CreateWindowExW(WS_EX_ACCEPTFILES, wc.lpszClassName, L"3P Compressor", style, x, y, w, hgt, nullptr, nullptr, inst, nullptr); // Compute and assign value
    if (!g.hwnd) return 1; // Conditional branch check
    enableDarkTitleBar(g.hwnd); // Execute statement
    DragAcceptFiles(g.hwnd, TRUE); // Execute statement
    ShowWindow(g.hwnd, show); // Execute statement

    int argc = 0; LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);     // "Open with" / double-click on a .3p
    if (argv && argc > 1) selectFile(fs::path(std::wstring(argv[1]))); // Conditional branch check
    if (argv) LocalFree(argv); // Conditional branch check

    MSG msg; // Execute statement
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageW(&msg); } // Loop while condition holds
    Gdiplus::GdiplusShutdown(g.gdiToken); // Execute statement
    return (int)msg.wParam; // Return result to caller
} // Close scope / block
