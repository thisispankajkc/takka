// p3prof.cpp - Latency & Core-Utilization Profiler for 3P Compressor
// Usage: p3prof <file> [-t threads] [-f|-m] [-v] [--no-dedup] [--no-detect]
#define P3_PROFILE 1 // Define preprocessor macro constant
#include "engine3p.hpp" // Include required header
#include <cstdio> // Include required header
#include <cstdlib> // Include required header
#include <string> // Include required header

using namespace p3; // Type alias or namespace import

static double ms(u64 us) { return (double)us / 1000.0; } // Define helper function or constant
static double pct(u64 part, u64 whole) { return whole ? (100.0 * (double)part / (double)whole) : 0.0; } // Define helper function or constant

int main(int argc, char** argv) { // Execute statement
    if (argc < 2) { // Conditional branch check
        std::fprintf(stderr, "Usage: p3prof <file> [-t threads] [-f|-m] [-v] [--no-dedup] [--no-detect] [outdir]\n"); // Execute statement
        return 2; // Return result to caller
    } // Close scope / block
    fs::path file = argv[1]; // Compute and assign value
    Options o; // Execute statement
    for (int i = 2; i < argc; i++) { // Loop iteration
        std::string a = argv[i]; // Compute and assign value
        if (a == "-t" && i + 1 < argc) o.threads = (unsigned)std::atoi(argv[++i]); // Conditional branch check
        else if (a == "-f") o.fast = true; // Alternative conditional branch
        else if (a == "-m") o.fast = false; // Alternative conditional branch
        else if (a == "-v") o.verify = true; // Alternative conditional branch
        else if (a == "--no-dedup") o.dedup = false; // Alternative conditional branch
        else if (a == "--no-detect") o.detect = false; // Alternative conditional branch
        else o.outDir = a; // Fallback branch
    } // Close scope / block

    Result r = compress_file(file, o, nullptr); // Compute and assign value
    if (r.status != Status::Ok) { // Conditional branch check
        std::fprintf(stderr, "ERROR(%d): %s\n", (int)r.status, r.message.c_str()); // Execute statement
        return 1; // Return result to caller
    } // Close scope / block

    const ProfStats& P = g_prof; // Compute and assign value
    double wallSec = (double)P.wallTotalUs / 1e6; // Compute and assign value
    double mbps = wallSec > 0 ? ((double)P.inBytes / 1e6 / wallSec) : 0.0; // Compute and assign value
    double ratio = P.inBytes ? (100.0 * (1.0 - (double)P.outBytes / (double)P.inBytes)) : 0.0; // Compute and assign value
    double effCores = P.workerWallUs ? ((double)P.wTotalActiveUs.load() / (double)P.workerWallUs) : 0.0; // Compute and assign value
    double utilPct = P.usedThreads ? (100.0 * effCores / (double)P.usedThreads) : 0.0; // Compute and assign value

    std::printf("\n==================== 3P LATENCY PROFILER ====================\n"); // Compute and assign value
    std::printf("File          : %s\n", file.string().c_str()); // Execute statement
    std::printf("Size          : %llu B -> %llu B  (%.2f%% smaller)\n", // Execute statement
                (unsigned long long)P.inBytes, (unsigned long long)P.outBytes, ratio); // Execute statement
    std::printf("Stream Len    : %llu B   Path: %s   Engine: %s\n", // Execute statement
                (unsigned long long)P.streamBytes, P.detectedPath.c_str(), // Execute statement
                P.fastMode ? "FAST (LZ77+rANS)" : "PAQ (Context-Mixing)"); // Execute statement
    std::printf("Config        : tbMax=%d  segSize=%zu KB  nseg=%llu  threads=%u/%u\n", // Segment sizing configuration
                P.tbMax, P.segSize >> 10, (unsigned long long)P.nseg, P.usedThreads, P.hwThreads); // Segment sizing configuration
    std::printf("Build Flags   : AVX2=%d  PREFETCH=%d  FAST_TRIALS=%d\n", // Compute and assign value
                (int)P3_AVX2_MIXER, (int)P3_LAYER1_PREFETCH, (int)P3_FAST_TRIALS); // Execute statement
    std::printf("Total Wall    : %.2f ms  (%.2f MB/s)\n", ms(P.wallTotalUs), mbps); // Execute statement
    std::printf("Parallelism   : %.2f / %u effective cores  (%.1f%% core utilization)\n", // Execute statement
                effCores, P.usedThreads, utilPct); // Execute statement

    std::printf("\n--- 1. WALL-CLOCK PHASES (Single-Thread Pre-Pass vs Parallel Workers) ---\n"); // Execute statement
    std::printf("  %-24s %10s %8s\n", "Phase", "Time (ms)", "% Wall"); // Execute statement
    auto rowW = [&](const char* name, u64 us) { // Compute and assign value
        std::printf("  %-24s %10.2f %7.2f%%\n", name, ms(us), pct(us, P.wallTotalUs)); // Execute statement
    }; // Close scope / block
    rowW("Pre: WAV/BMP detect", P.preWavBmpUs); // Execute statement
    rowW("Pre: JPEG-DCT",       P.preJpegUs); // Execute statement
    rowW("Pre: MT19937",        P.preMtUs); // Execute statement
    rowW("Pre: Deflate scan",   P.preDeflateUs); // Execute statement
    rowW("Pre: Dedup + CRC",    P.preDedupUs); // Execute statement
    rowW("Pre: Detect struct",  P.preDetectUs); // Execute statement
    rowW("Pre: Header write",   P.preHeaderUs); // Execute statement
    rowW("Workers (wall time)", P.workerWallUs); // Execute statement
    rowW("Finalize / flush",    P.finalizeUs); // Execute statement

    u64 wSum = P.wTotalActiveUs.load(); // Compute and assign value
    std::printf("\n--- 2. WORKER CPU-TIME BREAKDOWN (Sum across %u threads = %.2f ms) ---\n", // Compute and assign value
                P.usedThreads, ms(wSum)); // Execute statement
    std::printf("  %-24s %10s %8s\n", "Sub-Process", "CPU (ms)", "% Worker"); // Execute statement
    auto rowC = [&](const char* name, u64 us) { // Compute and assign value
        std::printf("  %-24s %10.2f %7.2f%%\n", name, ms(us), pct(us, wSum)); // Execute statement
    }; // Close scope / block
    rowC("Disk Read + CRC32",      P.wReadCrcUs.load()); // Execute statement
    rowC("Audio/Grid/Exec xform",  P.wTransformUs.load()); // Execute statement
    rowC("Model::reset (calloc)",  P.wModelResetUs.load()); // Execute statement
    if (!P.fastMode) { // Conditional branch check
        rowC("PAQ predict+update", P.wPaqModelUs.load()); // Execute statement
        rowC("PAQ Arith Coder",    P.wPaqAcUs.load()); // Execute statement
    } else { // Execute statement
        rowC("Fast LZ77 + Lazy",   P.wFastLzUs.load()); // Execute statement
        rowC("Fast rANS (O0/O1)",  P.wFastRansUs.load()); // Execute statement
    } // Close scope / block
    rowC("Verify (-v decode)",     P.wVerifyUs.load()); // Execute statement
    rowC("Queue/Lock Wait",        P.wQueueWaitUs.load()); // Execute statement
    rowC("Disk Write Drain",       P.wWriteDrainUs.load()); // Execute statement

    if (!P.fastMode) { // Conditional branch check
        u64 totBlk = P.blkModeled.load() + P.blkRaw.load() + P.blkSkipped.load(); // Compute and assign value
        std::printf("\n--- 3. PAQ 16KB BLOCK STATS (total=%llu) ---\n", (unsigned long long)totBlk); // Compute and assign value
        std::printf("  Modeled: %llu (%.1f%%)   Raw: %llu (%.1f%%)   Skipped: %llu (%.1f%%)\n", // Execute statement
                    (unsigned long long)P.blkModeled.load(), pct(P.blkModeled.load(), totBlk), // Execute statement
                    (unsigned long long)P.blkRaw.load(), pct(P.blkRaw.load(), totBlk), // Execute statement
                    (unsigned long long)P.blkSkipped.load(), pct(P.blkSkipped.load(), totBlk)); // Execute statement
    } // Close scope / block

    u64 sd = P.segDone.load(); // Compute and assign value
    if (sd > 0) { // Conditional branch check
        std::printf("\n--- 4. SEGMENT LATENCY & PER-THREAD LOAD BALANCE ---\n"); // Execute statement
        std::printf("  Seg Time (ms) : min=%.2f  avg=%.2f  max=%.2f\n", // Compute and assign value
                    ms(P.segMinUs.load()), ms(P.segSumUs.load() / sd), ms(P.segMaxUs.load())); // Execute statement
        std::printf("  %-6s %6s %11s %11s %11s\n", "Thread", "Segs", "Active(ms)", "Wait(ms)", "Write(ms)"); // Execute statement
        for (const auto& ti : P.threads) { // Loop iteration
            std::printf("  T%-5u %6llu %11.2f %11.2f %11.2f\n", // Execute statement
                        ti.id, (unsigned long long)ti.segs, ms(ti.activeUs), ms(ti.waitUs), ms(ti.writeUs)); // Execute statement
        } // Close scope / block
    } // Close scope / block
    std::printf("=============================================================\n"); // Compute and assign value
    return 0; // Return result to caller
} // Close scope / block
