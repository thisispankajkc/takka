# 3P Compressor Website & Multi-Platform Installer Suite (v18.9-Hardened)

Complete web application, online file compressor backend (`v18.9-Hardened`), and multi-platform installer packaging suite for **Windows (.exe Setup)**, **macOS (.dmg)**, and **Linux (.deb & universal .sh)**.

## Quick Start (Run Website Locally or on Server)

```bash
cd 3p-compressor-site
npm install
# On Linux x86_64, `p3cli` is already precompiled!
# On Windows, run: build-p3cli.bat
# On macOS, run:   clang++ -std=c++17 -O3 -DNDEBUG -pthread p3cli.cpp -o p3cli
npm start
```
Open **http://localhost:3000** in your browser.

## Ready-to-Install Packages (`downloads/` & `installers/`)

| Platform | Output Installer | Status / How to Build |
| :--- | :--- | :--- |
| **Linux (Debian/Ubuntu)** | `downloads/3P-Compressor-18.9-linux-amd64.deb` | **Prebuilt & ready to install** (`sudo dpkg -i ...`) |
| **Linux (Universal)** | `downloads/3P-Compressor-18.9-linux-setup.sh` | **Prebuilt & ready to install** (`./3P-Compressor-18.9-linux-setup.sh`) |
| **Windows 10/11 (x64)** | `downloads/3P-Compressor-Setup.exe` | Run `installers\windows\build-windows-setup.bat` (MinGW-w64 + Inno Setup 6) |
| **macOS 12+ (Universal)** | `downloads/3P-Compressor-macOS.dmg` | Run `bash installers/macos/build-macos-dmg.sh` on macOS (Xcode CLT) |

## Pricing & Contact
* **Personal / Standard:** Free
* **Corporate Subscription:** Let's talk
* **Email:** projectloweber@gmail.com
* **Phone:** +977 9800761880
