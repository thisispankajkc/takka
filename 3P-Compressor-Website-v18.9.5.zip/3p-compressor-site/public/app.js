const form = document.querySelector('#compress-form');
const picker = document.querySelector('#file-input');
const drop = document.querySelector('.dropzone');
const submit = document.querySelector('.submit-compress');
const status = document.querySelector('.upload-state');
const sizeLimit = 1024 * 1024 * 1024;
const browse = document.querySelector('.browse-button');
let selected = null;

const isPackedFile = file => file?.name.toLowerCase().endsWith('.3p');

function fmtSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(2)} MB`;
  return `${(bytes / 1073741824).toFixed(2)} GB`;
}

function createJobId() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const bytes = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.random() * 256;
  bytes[6] = (bytes[6] & 0x0f) | 0x40; bytes[8] = (bytes[8] & 0x3f) | 0x80;
  return [...bytes].map((b, i) => `${i === 4 || i === 6 || i === 8 || i === 10 ? '-' : ''}${b.toString(16).padStart(2, '0')}`).join('');
}

function choose(file) {
  if (!file) return;
  if (file.size > sizeLimit) {
    status.textContent = 'That file is over the 1 GB online limit. Use the free desktop app for unlimited sizes.';
    status.className = 'upload-state error';
    return;
  }
  selected = file;
  submit.disabled = false;
  const decompress = isPackedFile(file);
  submit.textContent = decompress ? 'De-Compress .3p' : 'Compress File';
  status.textContent = `${file.name} · ${fmtSize(file.size)} · ready to ${decompress ? 'decompress' : 'compress'}`;
  status.className = 'upload-state';
}

browse.addEventListener('click', () => picker.click());
picker.addEventListener('change', () => choose(picker.files[0]));
for (const ev of ['dragenter', 'dragover']) drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('is-over'); });
for (const ev of ['dragleave', 'drop']) drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('is-over'); });
drop.addEventListener('drop', e => choose(e.dataTransfer.files[0]));

form.addEventListener('submit', async e => {
  e.preventDefault();
  if (!selected) return;
  const decompress = isPackedFile(selected);
  const action = decompress ? 'De-Compressing' : 'Compressing';

  submit.disabled = true;
  submit.textContent = 'Working…';
  status.textContent = `Uploading and ${action.toLowerCase()} with 3P v18.9-Hardened…`;
  status.className = 'upload-state';

  const body = new FormData();
  body.append('file', selected);

  const jobId = createJobId();
  let polling = true;
  let pollBusy = false;
  const poll = async () => {
    if (!polling || pollBusy) return;
    pollBusy = true;
    try {
      const r = await fetch(`/api/compress-status/${jobId}`);
      if (!r.ok) return;
      const job = await r.json();
      if (job.state === 'uploading') status.textContent = 'Uploading file to 3P v18.9 backend…';
      else if (job.state === 'compressing' || job.state === 'decompressing') {
        status.textContent = `${job.state === 'decompressing' ? 'De-Compressing' : 'Compressing'} on server… ${Math.floor(job.progress || 0)}%`;
      } else if (job.state === 'ready') status.textContent = 'Processing complete. Preparing download…';
    } catch {} finally { pollBusy = false; }
  };
  const pollTimer = setInterval(poll, 800);
  poll();

  try {
    const response = await fetch('/api/compress', { method: 'POST', headers: { 'X-Job-ID': jobId }, body });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || 'Compression failed.');
    }
    const origBytes = Number(response.headers.get('X-Original-Bytes') || selected.size);
    const outBytes = Number(response.headers.get('X-Output-Bytes') || 0);
    const blob = await response.blob();
    const finalOut = outBytes || blob.size;
    const disposition = response.headers.get('content-disposition') || '';
    const encodedName = disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
    const quotedName = disposition.match(/filename="([^"]+)"/i)?.[1];
    const fallbackName = decompress ? selected.name.replace(/\.3p$/i, '') : `${selected.name.replace(/\.[^.]+$/, '') || selected.name}.3p`;
    let downloadName = fallbackName;
    try {
      if (encodedName) downloadName = decodeURIComponent(encodedName);
      else if (quotedName) downloadName = quotedName;
    } catch {}

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = downloadName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    if (decompress) {
      status.textContent = `Restored ${downloadName} (${fmtSize(finalOut)}) — 100% bit-exact.`;
    } else {
      const savedPct = origBytes > 0 ? Math.max(0, (1 - finalOut / origBytes) * 100).toFixed(1) : '0.0';
      status.textContent = `Done: ${fmtSize(origBytes)} → ${fmtSize(finalOut)} (${savedPct}% smaller). Downloaded ${downloadName}.`;
    }
    status.className = 'upload-state success';
  } catch (err) {
    status.textContent = err.message;
    status.className = 'upload-state error';
  } finally {
    polling = false;
    clearInterval(pollTimer);
    submit.disabled = true;
    submit.textContent = 'Compress File';
    selected = null;
    picker.value = '';
  }
});

const mobile = matchMedia('(max-width: 760px), (hover: none) and (pointer: coarse)');
function updateDownloads() {
  document.body.classList.toggle('mobile-browser', mobile.matches);
  for (const link of document.querySelectorAll('[data-installer]')) {
    const plat = link.getAttribute('data-installer');
    fetch(link.getAttribute('href'), { method: 'HEAD' }).then(r => {
      if (!r.ok) {
        if (plat === 'windows') {
          link.setAttribute('href', '/downloads/3P-Compressor-18.9-windows-kit.zip');
          link.setAttribute('download', '3P-Compressor-18.9-windows-kit.zip');
          link.innerHTML = 'Download Windows Build Kit (.zip) <span>↓</span>';
          link.title = 'Includes source + 1-click build-windows-setup.bat to generate 3P-Compressor-Setup.exe';
        } else if (plat === 'mac') {
          link.setAttribute('href', '/downloads/3P-Compressor-18.9-macos-kit.zip');
          link.setAttribute('download', '3P-Compressor-18.9-macos-kit.zip');
          link.innerHTML = 'Download macOS Build Kit (.zip) <span>↓</span>';
          link.title = 'Includes source + 1-click build-macos-dmg.sh to generate 3P-Compressor-macOS.dmg';
        } else {
          link.removeAttribute('download');
          link.removeAttribute('href');
          link.classList.add('unavailable');
          link.setAttribute('aria-disabled', 'true');
          link.innerHTML = 'Release pending <span>•</span>';
        }
      }
    }).catch(() => {});
  }
}
updateDownloads();
mobile.addEventListener?.('change', updateDownloads);
document.querySelector('.menu-toggle').addEventListener('click', () => document.querySelector('.topbar').classList.toggle('menu-open'));
