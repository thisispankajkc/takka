const express = require('express');
const multer = require('multer');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');

// Load local .env file without replacing host environment variables.
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  for (const rawLine of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const match = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match || process.env[match[1]] !== undefined) continue;
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    else value = value.replace(/\s+#.*$/, '').trim();
    process.env[match[1]] = value;
  }
}

const app = express();
const root = __dirname;
const uploadDir = path.join(os.tmpdir(), '3p-site-uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const maxBytes = Number(process.env.MAX_UPLOAD_MB || 1024) * 1024 * 1024;
const defaultThreads = Math.max(1, Math.min(os.cpus().length, Number(process.env.P3_THREADS || 4)));
const upload = multer({ dest: uploadDir, limits: { fileSize: maxBytes, files: 1 } });

let activeJobs = 0;
const jobs = new Map();

app.use(express.json({ limit: '16kb' }));
app.use(express.static(path.join(root, 'public')));
app.use('/downloads', express.static(path.join(root, 'downloads'), { fallthrough: true, dotfiles: 'deny' }));

// Graceful fallback if a platform installer (.exe or .dmg) has not been built into downloads/ yet
app.get('/downloads/:filename', (req, res) => {
  const fn = path.basename(req.params.filename || '');
  res.status(404).type('text/plain').send(
    `Installer "${fn}" is not built yet in the downloads/ folder.\n\n` +
    `To build platform installers:\n` +
    `  - Windows (.exe): Run installers\\windows\\build-windows-setup.bat on Windows\n` +
    `  - macOS (.dmg):   Run bash installers/macos/build-macos-dmg.sh on macOS\n` +
    `  - Linux (.deb):   Already prebuilt as downloads/3P-Compressor-18.9-linux-amd64.deb\n`
  );
});

function runCli(args, onProgress = () => {}) {
  return new Promise((resolve, reject) => {
    const exe = process.env.P3CLI || path.join(root, process.platform === 'win32' ? 'p3cli.exe' : 'p3cli');
    const child = spawn(exe, args, { windowsHide: true });
    let output = '';
    let progressTail = '';
    const collect = d => {
      const chunk = d.toString();
      output = (output + chunk).slice(-12000);
      progressTail = (progressTail + chunk).slice(-500);
      const matches = [...progressTail.matchAll(/(\d+(?:\.\d+)?)%\s+out\s+(\d+)/g)];
      if (matches.length) onProgress(Math.max(0, Math.min(100, Number(matches[matches.length - 1][1]))));
    };
    child.stdout.on('data', collect);
    child.stderr.on('data', collect);
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve(output) : reject(new Error(output || `Compressor exited with ${code}`)));
  });
}

app.get('/api/compress-status/:id', (req, res) => {
  const id = req.params.id;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'Invalid job ID.' });
  const job = jobs.get(id);
  if (!job) return res.status(404).json({ error: 'Compression job expired or was not found.' });
  res.json(job);
});

app.post('/api/compress', (req, res, next) => {
  const requestedId = req.get('X-Job-ID');
  req.compressionJobId = /^[0-9a-f-]{36}$/i.test(requestedId || '') ? requestedId : crypto.randomUUID();
  jobs.set(req.compressionJobId, { state: 'uploading', progress: 0 });
  setTimeout(() => jobs.delete(req.compressionJobId), 10 * 60 * 1000).unref?.();
  next();
}, upload.single('file'), async (req, res) => {
  const jobId = req.compressionJobId;
  if (!req.file) return res.status(400).json({ error: 'Choose a file to compress.' });
  if (activeJobs >= 3) {
    jobs.set(jobId, { state: 'error', progress: 0, error: 'The online compressor is busy. Please try again shortly.' });
    fs.rm(req.file.path, { force: true }, () => {});
    return res.status(429).json({ error: 'The online compressor is busy. Please try again shortly.' });
  }
  activeJobs++;
  const uploadedTmp = req.file.path;
  const origBytes = req.file.size;
  const safeName = path.basename(req.file.originalname || 'file').replace(/[\r\n<>:"/\\|?*\x00-\x1f]/g, '_') || 'file';
  const decompress = path.extname(safeName).toLowerCase() === '.3p';
  const action = decompress ? 'decompressing' : 'compressing';

  const workDir = fs.mkdtempSync(path.join(uploadDir, `${jobId}-`));
  const inDir = path.join(workDir, 'in');
  const outDir = path.join(workDir, 'out');
  fs.mkdirSync(inDir, { recursive: true });
  fs.mkdirSync(outDir, { recursive: true });
  const stagedInput = path.join(inDir, safeName);

  const cleanup = () => {
    fs.rm(uploadedTmp, { force: true }, () => {});
    fs.rm(workDir, { recursive: true, force: true }, () => {});
  };

  try {
    fs.copyFileSync(uploadedTmp, stagedInput);
    fs.rm(uploadedTmp, { force: true }, () => {});

    jobs.set(jobId, { state: action, progress: 0 });
    // Always use Fast (-f) default mode for compression
    const cliArgs = decompress
      ? ['x', stagedInput, outDir, '-t', String(defaultThreads)]
      : ['c', stagedInput, outDir, '-f', '-t', String(defaultThreads)];

    await runCli(cliArgs, progress => jobs.set(jobId, { state: action, progress }));

    const outputs = fs.readdirSync(outDir).filter(name => name !== '.' && name !== '..');
    if (outputs.length !== 1) throw new Error('Compressor did not create exactly one output file.');

    const outputPath = path.join(outDir, outputs[0]);
    const outBytes = fs.statSync(outputPath).size;
    const downloadName = decompress ? outputs[0] : `${path.parse(safeName).name}.3p`;

    jobs.set(jobId, { state: 'ready', action, progress: 100, inBytes: origBytes, outBytes });
    res.setHeader('X-Original-Bytes', String(origBytes));
    res.setHeader('X-Output-Bytes', String(outBytes));
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, X-Original-Bytes, X-Output-Bytes');

    res.download(outputPath, downloadName, err => {
      activeJobs--;
      cleanup();
      if (err && !res.headersSent) res.status(500).end();
    });
  } catch (error) {
    activeJobs--;
    cleanup();
    console.error('Compression failed:', error.message);
    jobs.set(jobId, { state: 'error', progress: 0, error: error.message });
    if (error.code === 'ENOENT') {
      return res.status(503).json({ error: 'The 3P v18.9 compressor binary is not built yet. Run build-p3cli.bat (Windows) or g++ -std=c++17 -O3 -pthread p3cli.cpp -o p3cli (Linux/macOS).' });
    }
    if (String(error.message).includes('3221225785') || String(error.message).toLowerCase().includes('c0000139')) {
      return res.status(503).json({ error: 'Windows could not load p3cli.exe (0xC0000139). Rebuild with build-p3cli-msvc.bat from x64 Native Tools Command Prompt.' });
    }
    const engineMessage = error.message.match(/error\(\d+\):\s*([^\r\n]+)/i)?.[1];
    res.status(500).json({ error: engineMessage ? `${decompress ? 'Decompression' : 'Compression'} failed: ${engineMessage}` : 'File processing failed. Check server logs.' });
  }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, engine: '3P-Compressor v18.9-Hardened' }));

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    return res.status(err.code === 'LIMIT_FILE_SIZE' ? 413 : 400).json({
      error: err.code === 'LIMIT_FILE_SIZE' ? `Maximum file size is ${process.env.MAX_UPLOAD_MB || 1024} MB.` : 'Upload could not be accepted.'
    });
  }
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error.' });
});

const port = Number(process.env.PORT || 3000);
const server = app.listen(port, () => console.log(`3P Compressor v18.9-Hardened site listening on port ${port} (max upload: ${process.env.MAX_UPLOAD_MB || 1024} MB)`));
server.requestTimeout = 30 * 60 * 1000;
server.headersTimeout = 30 * 60 * 1000;
